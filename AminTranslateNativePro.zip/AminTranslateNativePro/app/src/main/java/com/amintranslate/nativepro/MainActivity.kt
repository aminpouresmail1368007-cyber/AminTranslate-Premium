package com.amintranslate.nativepro

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoAwesomeMotion
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardVoice
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val viewModel by viewModels<AppViewModel>()
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { }
        setContent {
            val state by viewModel.state.collectAsStateWithLifecycle()
            AminTranslateTheme(state.darkMode) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AminTranslateApp(
                        state = state,
                        viewModel = viewModel,
                        onSpeak = { text, language -> speak(text, language) }
                    )
                }
            }
        }
    }

    private fun speak(text: String, language: String) {
        if (text.isBlank()) return
        tts?.language = Locale.forLanguageTag(language)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "amintranslate")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

private val DarkColors = darkColorScheme(
    primary = Color(0xFF3DE0BE),
    secondary = Color(0xFF9B82FF),
    tertiary = Color(0xFF61B8FF),
    background = Color(0xFF07111F),
    surface = Color(0xFF0D1B2D),
    surfaceVariant = Color(0xFF12253B),
    onPrimary = Color(0xFF00261F),
    onBackground = Color(0xFFEAF2FF),
    onSurface = Color(0xFFEAF2FF),
    onSurfaceVariant = Color(0xFFAFC0D8)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF006B58),
    secondary = Color(0xFF5C45B8),
    background = Color(0xFFF4F7FB),
    surface = Color.White,
    surfaceVariant = Color(0xFFE8EEF7)
)

@Composable
private fun AminTranslateTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        content = content
    )
}

private enum class MainTab(val title: String, val icon: ImageVector) {
    Translate("ترجمه", Icons.Default.Translate),
    Media("رسانه", Icons.Default.AutoAwesomeMotion),
    History("تاریخچه", Icons.Default.History),
    Settings("تنظیمات", Icons.Default.Settings)
}

@Composable
private fun AminTranslateApp(
    state: AppUiState,
    viewModel: AppViewModel,
    onSpeak: (String, String) -> Unit
) {
    var tab by remember { mutableStateOf(MainTab.Translate) }
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val text = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
            .orEmpty()
        viewModel.useVoiceResult(text)
    }

    val microphonePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val localeTag = state.sourceLanguage.code
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "صحبت کن؛ AminTranslate در حال شنیدن است")
            }
            voiceLauncher.launch(intent)
        }
    }

    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.processImage(uri)
    }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.processVideo(uri)
    }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
                modifier = Modifier.navigationBarsPadding()
            ) {
                MainTab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(item.icon, null) },
                        label = { Text(item.title, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .padding(padding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                PremiumHeader(state)
                if (state.error != null) ErrorCard(state.error)

                AnimatedContent(targetState = tab, label = "main-tab") { selected ->
                    when (selected) {
                        MainTab.Translate -> TranslateScreen(
                            state = state,
                            viewModel = viewModel,
                            onVoice = { microphonePermission.launch(Manifest.permission.RECORD_AUDIO) },
                            onCopy = { clipboard.setText(AnnotatedString(state.outputText)) },
                            onShare = { shareText(context, state.outputText) },
                            onSpeak = { onSpeak(state.outputText, state.targetLanguage.code) }
                        )
                        MainTab.Media -> MediaScreen(
                            state = state,
                            viewModel = viewModel,
                            onVoice = { microphonePermission.launch(Manifest.permission.RECORD_AUDIO) },
                            onImage = { imageLauncher.launch("image/*") },
                            onVideo = { videoLauncher.launch("video/*") },
                            onCopy = { clipboard.setText(AnnotatedString(state.outputText)) },
                            onSpeak = { onSpeak(state.outputText, state.targetLanguage.code) }
                        )
                        MainTab.History -> HistoryScreen(state, viewModel)
                        MainTab.Settings -> SettingsScreen(state, viewModel)
                    }
                }
            }
        }
    }
}

@Composable
private fun PremiumHeader(state: AppUiState) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f),
                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                            MaterialTheme.colorScheme.surface
                        )
                    )
                )
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.18f), RoundedCornerShape(28.dp))
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("AminTranslate", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                        Text(
                            "Native Pro",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                    }
                }
                Text(
                    "ترجمه واقعی متن، صدا، تصویر و ویدیو",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusChip("Native Android", MaterialTheme.colorScheme.primary)
                    StatusChip("On-device AI", MaterialTheme.colorScheme.secondary)
                }
                Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (state.busy) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(state.status, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun StatusChip(text: String, color: Color) {
    Text(
        text,
        color = color,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(CircleShape)
            .background(color.copy(alpha = 0.10f))
            .border(1.dp, color.copy(alpha = 0.20f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    )
}

@Composable
private fun ErrorCard(message: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Text(
            message,
            color = MaterialTheme.colorScheme.onErrorContainer,
            modifier = Modifier.padding(14.dp),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun TranslateScreen(
    state: AppUiState,
    viewModel: AppViewModel,
    onVoice: () -> Unit,
    onCopy: () -> Unit,
    onShare: (() -> Unit)?,
    onSpeak: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("ترجمه متن", "موتور ترجمه روی دستگاه")
        LanguageBar(state, viewModel)
        InputCard(state, viewModel, onVoice)
        GradientActionButton(
            title = if (state.busy) "در حال پردازش…" else "ترجمه کن",
            icon = Icons.Default.Translate,
            enabled = !state.busy && state.inputText.isNotBlank(),
            onClick = { viewModel.translateCurrent() }
        )
        OutputCard(state, onCopy, onShare, onSpeak)
    }
}

@Composable
private fun MediaScreen(
    state: AppUiState,
    viewModel: AppViewModel,
    onVoice: () -> Unit,
    onImage: () -> Unit,
    onVideo: () -> Unit,
    onCopy: () -> Unit,
    onSpeak: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("استودیوی رسانه", "ورودی واقعی از میکروفون، تصویر و ویدیو")
        LanguageBar(state, viewModel)

        FeatureActionCard(
            icon = Icons.Default.RecordVoiceOver,
            title = "ترجمه گفتار",
            subtitle = "صحبت کن، متن تشخیص داده می‌شود و همان لحظه ترجمه می‌شود.",
            button = "شروع شنیدن",
            enabled = !state.busy,
            onClick = onVoice
        )

        OcrLanguageSelector(state, viewModel)
        FeatureActionCard(
            icon = Icons.Default.Image,
            title = "ترجمه تصویر",
            subtitle = "OCR فارسی و انگلیسی با Tesseract؛ مدل در اولین استفاده دانلود می‌شود.",
            button = "انتخاب تصویر",
            enabled = !state.busy,
            onClick = onImage
        )

        VideoSpeechSelector(state, viewModel)
        FeatureActionCard(
            icon = Icons.Default.VideoFile,
            title = "ترجمه ویدیو",
            subtitle = "صدای ویدیو را روی گوشی استخراج و با Vosk تبدیل به متن می‌کند، سپس ترجمه می‌کند.",
            button = "انتخاب ویدیو",
            enabled = !state.busy,
            onClick = onVideo
        )

        if (state.videoTranscript.isNotBlank()) {
            InfoTextCard("متن استخراج‌شده از ویدیو", state.videoTranscript)
        }
        if (state.outputText.isNotBlank()) {
            OutputCard(state, onCopy, null, onSpeak)
        }
    }
}

@Composable
private fun LanguageBar(state: AppUiState, viewModel: AppViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(Modifier.weight(1f)) {
                LanguageDropdown("از", state.sourceLanguage, onSelect = viewModel::setSource)
            }
            IconButton(
                onClick = viewModel::swapLanguages,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
            ) {
                Icon(Icons.Default.SwapHoriz, null, tint = MaterialTheme.colorScheme.primary)
            }
            Box(Modifier.weight(1f)) {
                LanguageDropdown("به", state.targetLanguage, onSelect = viewModel::setTarget)
            }
        }
    }
}

@Composable
private fun LanguageDropdown(label: String, selected: LanguageOption, onSelect: (LanguageOption) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                .clickable { expanded = true }
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(selected.labelFa, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            supportedLanguages.forEach { language ->
                DropdownMenuItem(
                    text = { Text("${language.labelFa}  •  ${language.labelEn}") },
                    onClick = {
                        expanded = false
                        onSelect(language)
                    }
                )
            }
        }
    }
}

@Composable
private fun InputCard(state: AppUiState, viewModel: AppViewModel, onVoice: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("متن اصلی", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                IconButton(onClick = onVoice) {
                    Icon(Icons.Default.Mic, null, tint = MaterialTheme.colorScheme.primary)
                }
            }
            BasicTextField(
                value = state.inputText,
                onValueChange = viewModel::setInput,
                textStyle = TextStyle(
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 17.sp,
                    lineHeight = 27.sp,
                    textAlign = TextAlign.Start
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.45f))
                    .padding(15.dp),
                decorationBox = { inner ->
                    Box {
                        if (state.inputText.isBlank()) {
                            Text("متن را اینجا بنویس یا از میکروفون استفاده کن…", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f))
                        }
                        inner()
                    }
                }
            )
            Text("${state.inputText.length} نویسه", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OutputCard(
    state: AppUiState,
    onCopy: () -> Unit,
    onShare: (() -> Unit)?,
    onSpeak: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().animateContentSize()
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ترجمه", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(state.targetLanguage.labelFa, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                }
                Row {
                    IconButton(onClick = onSpeak, enabled = state.outputText.isNotBlank()) {
                        Icon(Icons.Default.VolumeUp, null)
                    }
                    IconButton(onClick = onCopy, enabled = state.outputText.isNotBlank()) {
                        Icon(Icons.Default.ContentCopy, null)
                    }
                    if (onShare != null) {
                        IconButton(onClick = onShare, enabled = state.outputText.isNotBlank()) {
                            Icon(Icons.Default.Share, null)
                        }
                    }
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), RoundedCornerShape(18.dp))
                    .padding(15.dp)
            ) {
                Text(
                    if (state.outputText.isBlank()) "نتیجه ترجمه اینجا نمایش داده می‌شود." else state.outputText,
                    color = if (state.outputText.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface,
                    fontSize = 17.sp,
                    lineHeight = 27.sp
                )
            }
        }
    }
}

@Composable
private fun GradientActionButton(
    title: String,
    icon: ImageVector,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val alpha = if (enabled) 1f else 0.45f
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.primary.copy(alpha = alpha),
                        MaterialTheme.colorScheme.secondary.copy(alpha = alpha)
                    )
                )
            )
            .clickable(enabled = enabled, onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Color(0xFF06131F))
        Spacer(Modifier.width(9.dp))
        Text(title, color = Color(0xFF06131F), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
    }
}

@Composable
private fun FeatureActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    button: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(subtitle, fontSize = 12.sp, lineHeight = 19.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            OutlinedButton(
                onClick = onClick,
                enabled = enabled,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(button, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun OcrLanguageSelector(state: AppUiState, viewModel: AppViewModel) {
    SimpleChoiceRow(
        title = "زبان OCR",
        choices = listOf("fas+eng" to "فارسی + انگلیسی", "fas" to "فارسی", "eng" to "English"),
        selected = state.ocrLanguage,
        onSelect = viewModel::setOcrLanguage
    )
}

@Composable
private fun VideoSpeechSelector(state: AppUiState, viewModel: AppViewModel) {
    SimpleChoiceRow(
        title = "زبان گفتار ویدیو",
        choices = listOf("fa" to "فارسی", "en" to "English"),
        selected = state.videoSpeechLanguage,
        onSelect = viewModel::setVideoSpeechLanguage
    )
}

@Composable
private fun SimpleChoiceRow(
    title: String,
    choices: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            choices.forEach { (code, label) ->
                val active = selected == code
                Text(
                    label,
                    color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.10f) else MaterialTheme.colorScheme.surface)
                        .border(1.dp, if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.35f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f), CircleShape)
                        .clickable { onSelect(code) }
                        .padding(horizontal = 13.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun HistoryScreen(state: AppUiState, viewModel: AppViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionTitle("تاریخچه", "آخرین ۱۰۰ ترجمه روی همین گوشی")
            IconButton(onClick = viewModel::clearHistory, enabled = state.history.isNotEmpty()) {
                Icon(Icons.Default.ClearAll, null, tint = MaterialTheme.colorScheme.error)
            }
        }
        if (state.history.isEmpty()) {
            EmptyState("هنوز ترجمه‌ای ذخیره نشده.")
        } else {
            state.history.forEach { item -> HistoryCard(item) }
        }
    }
}

@Composable
private fun HistoryCard(item: HistoryEntry) {
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()) }
    val type = when (item.kind) {
        "voice" -> "صدا"
        "image" -> "تصویر"
        "video" -> "ویدیو"
        else -> "متن"
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$type  •  ${item.sourceCode.uppercase()} → ${item.targetCode.uppercase()}", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(fmt.format(Date(item.createdAt)), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
            }
            Text(item.input, maxLines = 3, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
            Text(item.output, maxLines = 4, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun SettingsScreen(state: AppUiState, viewModel: AppViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("تنظیمات", "کنترل ظاهر و اطلاعات موتور")
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (state.darkMode) Icons.Default.DarkMode else Icons.Default.LightMode, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("حالت تاریک", fontWeight = FontWeight.Bold)
                        Text("ظاهر حرفه‌ای و مناسب استفاده طولانی", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Switch(checked = state.darkMode, onCheckedChange = viewModel::setDarkMode)
            }
        }
        InfoTextCard(
            "موتورهای واقعی برنامه",
            "• ترجمه متن: Google ML Kit روی دستگاه\n• OCR: Tesseract 5 برای فارسی/انگلیسی\n• گفتار زنده: Android Speech Recognizer\n• گفتار ویدیو: Vosk Offline\n• ذخیره تاریخچه: حافظه محلی گوشی"
        )
        InfoTextCard(
            "درباره سازنده",
            "Dr. Amin Pour Esmaeil\nPhD Pathogenic Microbiology\nAminTranslate Native Pro — Version 1.0"
        )
        InfoTextCard(
            "نکته مهم مدل‌ها",
            "برای اولین ترجمه هر جفت زبان، مدل ML Kit دانلود می‌شود. OCR و ویدیو هم در اولین استفاده مدل لازم را می‌گیرند؛ بعد از آن بخش زیادی از پردازش روی خود گوشی انجام می‌شود."
        )
    }
}

@Composable
private fun InfoTextCard(title: String, text: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(text, fontSize = 13.sp, lineHeight = 21.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
        Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
    ) {
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun shareText(context: android.content.Context, text: String) {
    if (text.isBlank()) return
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(send, "اشتراک ترجمه"))
}
