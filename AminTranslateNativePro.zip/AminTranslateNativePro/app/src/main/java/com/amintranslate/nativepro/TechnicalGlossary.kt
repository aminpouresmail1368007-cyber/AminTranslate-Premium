package com.amintranslate.nativepro

/**
 * Terminology guard for the on-device fallback translator.
 * It protects scientific tokens and pins high-value English/Persian technical phrases
 * to curated equivalents before Google ML Kit sees the surrounding sentence.
 */
object TechnicalGlossary {
    data class PreparedText(val text: String, val replacements: Map<String, String>) {
        fun restore(translated: String): String {
            var out = translated
            replacements.forEach { (token, value) ->
                out = out.replace(token, value, ignoreCase = true)
                out = out.replace(token.replace("_", " _ "), value, ignoreCase = true)
            }
            return cleanup(out)
        }
    }

    fun prepare(text: String, source: String, target: String, domain: TranslationDomain): PreparedText {
        if (text.isBlank()) return PreparedText(text, emptyMap())
        var working = text
        val replacements = linkedMapOf<String, String>()
        var index = 0

        fun protect(regex: Regex, transform: (String) -> String = { it }) {
            working = regex.replace(working) { match ->
                val token = "__ATX${index++}__"
                replacements[token] = transform(match.value)
                token
            }
        }

        // Values that should never be mistranslated.
        protect(Regex("https?://\\S+|www\\.\\S+", RegexOption.IGNORE_CASE))
        protect(Regex("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", RegexOption.IGNORE_CASE))
        protect(Regex("10\\.\\d{4,9}/[-._;()/:A-Z0-9]+", RegexOption.IGNORE_CASE))
        protect(Regex("\\b(?:DNA|RNA|mRNA|PCR|qPCR|RT-PCR|ELISA|HLA|MHC|IgG|IgM|IgA|IgE|CRP|ESR|CBC|WBC|RBC|Hb|Hct|AST|ALT|ALP|BUN|eGFR|MIC|MBC|CFU|AST|CLSI|EUCAST|MDR|XDR|PDR|MRSA|VRE|ESBL|CRE|CAR-T|CD4|CD8|CD19|CD20|TNF|IL-6|IFN-γ|SARS-CoV-2|COVID-19|HIV|HBV|HCV|HPV)\\b"))
        protect(Regex("\\b\\d+(?:[.,]\\d+)?\\s?(?:mg|g|kg|µg|ug|ng|mL|ml|L|µL|uL|mmol/L|mg/dL|IU/L|U/L|mmHg|bpm|°C|%|kDa|bp|kb|rpm|h|min|s)\\b", RegexOption.IGNORE_CASE))

        val glossary = when {
            source.startsWith("en") && target.startsWith("fa") -> enToFa(domain)
            source.startsWith("fa") && target.startsWith("en") -> enToFa(domain).entries.associate { (en, fa) -> fa to en }
            else -> emptyMap()
        }

        glossary.entries.sortedByDescending { it.key.length }.forEach { (from, to) ->
            val pattern = if (from.any { it.code > 127 }) {
                Regex(Regex.escape(from), RegexOption.IGNORE_CASE)
            } else {
                Regex("(?<![A-Za-z0-9])${Regex.escape(from)}(?![A-Za-z0-9])", RegexOption.IGNORE_CASE)
            }
            working = pattern.replace(working) {
                val token = "__ATX${index++}__"
                replacements[token] = to
                token
            }
        }

        return PreparedText(working, replacements)
    }

    private fun enToFa(domain: TranslationDomain): Map<String, String> {
        val common = linkedMapOf(
            "sensitivity" to "حساسیت",
            "specificity" to "ویژگی",
            "positive predictive value" to "ارزش اخباری مثبت",
            "negative predictive value" to "ارزش اخباری منفی",
            "confidence interval" to "فاصله اطمینان",
            "odds ratio" to "نسبت شانس",
            "relative risk" to "خطر نسبی",
            "hazard ratio" to "نسبت خطر",
            "systematic review" to "مرور نظام‌مند",
            "meta-analysis" to "فراتحلیل",
            "randomized controlled trial" to "کارآزمایی تصادفی‌سازی‌شده کنترل‌شده",
            "cross-sectional study" to "مطالعه مقطعی",
            "cohort study" to "مطالعه هم‌گروهی",
            "case-control study" to "مطالعه مورد-شاهدی",
            "statistical significance" to "معناداری آماری",
            "clinical significance" to "اهمیت بالینی",
            "standard deviation" to "انحراف معیار",
            "standard error" to "خطای استاندارد",
            "sample size" to "حجم نمونه",
            "bias" to "سوگیری",
            "confounding" to "مخدوش‌گری",
            "validation" to "اعتبارسنجی",
            "quality control" to "کنترل کیفیت",
            "quality assurance" to "تضمین کیفیت",
            "root cause analysis" to "تحلیل علت ریشه‌ای",
            "risk assessment" to "ارزیابی ریسک"
        )

        val medical = linkedMapOf(
            "antimicrobial resistance" to "مقاومت ضد‌میکروبی",
            "antibiotic resistance" to "مقاومت آنتی‌بیوتیکی",
            "antimicrobial susceptibility testing" to "آزمون حساسیت ضد‌میکروبی",
            "minimum inhibitory concentration" to "حداقل غلظت مهاری",
            "minimum bactericidal concentration" to "حداقل غلظت باکتری‌کشی",
            "disk diffusion" to "انتشار دیسکی",
            "broth microdilution" to "میکرودایلوشن در محیط مایع",
            "blood culture" to "کشت خون",
            "urine culture" to "کشت ادرار",
            "culture medium" to "محیط کشت",
            "selective medium" to "محیط انتخابی",
            "differential medium" to "محیط افتراقی",
            "colony forming unit" to "واحد تشکیل‌دهنده کلنی",
            "bacterial load" to "بار باکتریایی",
            "viral load" to "بار ویروسی",
            "biofilm" to "بیوفیلم",
            "quorum sensing" to "حس‌کردن حد نصاب",
            "virulence factor" to "عامل بیماری‌زایی",
            "pathogenicity" to "بیماری‌زایی",
            "opportunistic pathogen" to "پاتوژن فرصت‌طلب",
            "nosocomial infection" to "عفونت بیمارستانی",
            "healthcare-associated infection" to "عفونت مرتبط با مراقبت سلامت",
            "infection prevention and control" to "پیشگیری و کنترل عفونت",
            "standard precautions" to "احتیاطات استاندارد",
            "contact precautions" to "احتیاطات تماسی",
            "droplet precautions" to "احتیاطات قطره‌ای",
            "airborne precautions" to "احتیاطات هوابرد",
            "hand hygiene" to "بهداشت دست",
            "sterilization" to "استریلیزاسیون",
            "disinfection" to "گندزدایی",
            "decontamination" to "آلودگی‌زدایی",
            "incubation period" to "دوره کمون",
            "pathogen" to "عامل بیماری‌زا",
            "isolate" to "ایزوله میکروبی",
            "strain" to "سویه",
            "genotype" to "ژنوتیپ",
            "phenotype" to "فنوتیپ",
            "whole genome sequencing" to "توالی‌یابی کل ژنوم",
            "next-generation sequencing" to "توالی‌یابی نسل جدید",
            "polymerase chain reaction" to "واکنش زنجیره‌ای پلیمراز",
            "reverse transcription" to "رونویسی معکوس",
            "nucleic acid amplification test" to "آزمون تقویت اسید نوکلئیک",
            "primer" to "پرایمر",
            "probe" to "پروب",
            "amplicon" to "آمپلیکون",
            "cycle threshold" to "آستانه چرخه",
            "limit of detection" to "حد تشخیص",
            "limit of quantification" to "حد کمّی‌سازی",
            "false positive" to "مثبت کاذب",
            "false negative" to "منفی کاذب",
            "serology" to "سرولوژی",
            "antibody" to "آنتی‌بادی",
            "antigen" to "آنتی‌ژن",
            "monoclonal antibody" to "آنتی‌بادی مونوکلونال",
            "polyclonal antibody" to "آنتی‌بادی پلی‌کلونال",
            "enzyme-linked immunosorbent assay" to "آزمون ایمونوسوربنت متصل به آنزیم",
            "flow cytometry" to "فلوسایتومتری",
            "immunofluorescence" to "ایمونوفلورسانس",
            "immunohistochemistry" to "ایمونوهیستوشیمی",
            "major histocompatibility complex" to "مجموعه سازگاری بافتی اصلی",
            "human leukocyte antigen" to "آنتی‌ژن لکوسیتی انسانی",
            "donor-specific antibody" to "آنتی‌بادی اختصاصی دهنده",
            "crossmatch" to "کراس‌مچ",
            "histocompatibility" to "سازگاری بافتی",
            "immune response" to "پاسخ ایمنی",
            "innate immunity" to "ایمنی ذاتی",
            "adaptive immunity" to "ایمنی اکتسابی",
            "cell-mediated immunity" to "ایمنی سلولی",
            "humoral immunity" to "ایمنی هومورال",
            "cytokine" to "سیتوکین",
            "chemokine" to "کموکاین",
            "inflammation" to "التهاب",
            "sepsis" to "سپسیس",
            "septic shock" to "شوک سپتیک",
            "bacteremia" to "باکتریمی",
            "viremia" to "ویرمی",
            "fungemia" to "قارچ‌خونی",
            "clinical specimen" to "نمونه بالینی",
            "reference range" to "محدوده مرجع",
            "critical value" to "مقدار بحرانی",
            "turnaround time" to "زمان پاسخ‌دهی",
            "pre-analytical error" to "خطای پیش‌تحلیلی",
            "analytical error" to "خطای تحلیلی",
            "post-analytical error" to "خطای پس‌تحلیلی",
            "internal quality control" to "کنترل کیفیت داخلی",
            "external quality assessment" to "ارزیابی خارجی کیفیت",
            "proficiency testing" to "آزمون مهارت",
            "calibration" to "کالیبراسیون",
            "traceability" to "قابلیت ردیابی",
            "reference method" to "روش مرجع",
            "diagnostic accuracy" to "دقت تشخیصی",
            "clinical laboratory" to "آزمایشگاه بالینی",
            "microbiology laboratory" to "آزمایشگاه میکروب‌شناسی",
            "hematology" to "هماتولوژی",
            "biochemistry" to "بیوشیمی",
            "immunology" to "ایمونولوژی",
            "molecular diagnostics" to "تشخیص مولکولی"
        )

        val engineering = linkedMapOf(
            "artificial intelligence" to "هوش مصنوعی",
            "machine learning" to "یادگیری ماشین",
            "deep learning" to "یادگیری عمیق",
            "neural network" to "شبکه عصبی",
            "large language model" to "مدل زبانی بزرگ",
            "application programming interface" to "رابط برنامه‌نویسی کاربردی",
            "database" to "پایگاه داده",
            "data pipeline" to "خط لوله داده",
            "cloud computing" to "رایانش ابری",
            "cybersecurity" to "امنیت سایبری",
            "encryption" to "رمزنگاری",
            "authentication" to "احراز هویت",
            "authorization" to "مجوزدهی",
            "source code" to "کد منبع",
            "runtime" to "زمان اجرا",
            "latency" to "تأخیر",
            "throughput" to "توان عملیاتی",
            "scalability" to "مقیاس‌پذیری",
            "fault tolerance" to "تحمل خطا"
        )

        val legalBusiness = linkedMapOf(
            "contract" to "قرارداد",
            "agreement" to "توافق‌نامه",
            "liability" to "مسئولیت حقوقی",
            "confidentiality" to "محرمانگی",
            "intellectual property" to "مالکیت فکری",
            "compliance" to "انطباق",
            "regulatory requirement" to "الزام مقرراتی",
            "stakeholder" to "ذی‌نفع",
            "key performance indicator" to "شاخص کلیدی عملکرد",
            "cost-effectiveness" to "هزینه‌اثربخشی",
            "return on investment" to "بازگشت سرمایه"
        )

        return when (domain) {
            TranslationDomain.MEDICAL_LAB -> common + medical
            TranslationDomain.SCIENTIFIC_ACADEMIC -> common + medical
            TranslationDomain.ENGINEERING_IT -> common + engineering
            TranslationDomain.LEGAL_BUSINESS -> common + legalBusiness
            TranslationDomain.AUTO_EXPERT -> common + medical + engineering + legalBusiness
            TranslationDomain.GENERAL -> common
        }
    }

    private fun cleanup(text: String): String = text
        .replace("ي", "ی")
        .replace("ك", "ک")
        .replace(Regex("[ \\t]+"), " ")
        .replace(Regex(" *\\n *"), "\n")
        .trim()
}
