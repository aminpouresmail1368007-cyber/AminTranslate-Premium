package com.amintranslate.nativepro

import com.google.mlkit.nl.languageid.LanguageIdentification
import kotlinx.coroutines.tasks.await

class LanguageDetector {
    suspend fun detect(text: String): String {
        if (text.isBlank()) return "und"
        val identifier = LanguageIdentification.getClient()
        return try {
            identifier.identifyLanguage(text.take(6000)).await()
        } finally {
            identifier.close()
        }
    }
}
