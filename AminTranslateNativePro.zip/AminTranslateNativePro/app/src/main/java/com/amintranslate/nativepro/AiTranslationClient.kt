package com.amintranslate.nativepro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class AiTranslationClient {
    suspend fun translate(
        text: String,
        source: LanguageOption,
        target: LanguageOption,
        domain: TranslationDomain,
        apiKey: String,
        model: String
    ): String = translateMany(listOf(text), source, target, domain, apiKey, model).first()

    suspend fun translateMany(
        texts: List<String>,
        source: LanguageOption,
        target: LanguageOption,
        domain: TranslationDomain,
        apiKey: String,
        model: String
    ): List<String> = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "کلید API برای ترجمه AI تنظیم نشده است." }
        if (texts.isEmpty()) return@withContext emptyList()
        if (source.code == target.code) return@withContext texts

        val inputArray = JSONArray()
        texts.forEachIndexed { index, text ->
            inputArray.put(JSONObject().put("id", index).put("text", text))
        }

        val request = JSONObject()
            .put("model", model.ifBlank { "gpt-6-astra" })
            .put("instructions", buildInstructions(source, target, domain))
            .put(
                "input",
                "Translate the JSON array below. Return ONLY a valid JSON array with the same ids and a field named translation. " +
                    "Do not add markdown or commentary.\n" + inputArray.toString()
            )
            .put("max_output_tokens", maxOf(1200, texts.sumOf { it.length } * 2).coerceAtMost(8000))

        val connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            setRequestProperty("Content-Type", "application/json")
        }

        try {
            connection.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            if (code !in 200..299) {
                val message = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                error(message?.takeIf { it.isNotBlank() } ?: "خطای سرویس ترجمه آنلاین: HTTP $code")
            }

            val outputText = extractOutputText(JSONObject(raw)).trim()
            val clean = outputText
                .removePrefix("```json").removePrefix("```")
                .removeSuffix("```").trim()
            val array = JSONArray(clean)
            val translatedById = mutableMapOf<Int, String>()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                translatedById[item.getInt("id")] = item.getString("translation").trim()
            }
            texts.indices.map { index -> translatedById[index] ?: error("پاسخ ترجمه ناقص بود.") }
        } finally {
            connection.disconnect()
        }
    }

    private fun buildInstructions(source: LanguageOption, target: LanguageOption, domain: TranslationDomain): String {
        val domainPrompt = when (domain) {
            TranslationDomain.MEDICAL_LAB -> "medical, clinical laboratory, microbiology, immunology, pathology, molecular diagnostics and biomedical terminology"
            TranslationDomain.SCIENTIFIC_ACADEMIC -> "academic and scientific writing, research methods, statistics and publication terminology"
            TranslationDomain.ENGINEERING_IT -> "engineering, software, information technology, AI, data and cybersecurity terminology"
            TranslationDomain.LEGAL_BUSINESS -> "legal, administrative, management, finance and business terminology"
            TranslationDomain.GENERAL -> "general natural language"
            TranslationDomain.AUTO_EXPERT -> "automatically infer the subject domain and use the most authoritative professional terminology for it"
        }
        return """
            You are the high-precision professional translation engine inside AminTranslate.
            Translate from ${source.labelEn} (${source.code}) to ${target.labelEn} (${target.code}).
            Domain priority: $domainPrompt.
            Requirements:
            - Preserve meaning, register, tone, paragraph structure, numbers and negation exactly.
            - Use standard professional terminology, not literal word-by-word translation.
            - Resolve ambiguous terminology from surrounding context before choosing the target-language equivalent.
            - In specialist material, prefer terminology used in peer-reviewed literature, clinical guidelines, standards and professional practice.
            - Keep gene/protein names, organism names, drug names, abbreviations, units, formulas, URLs, DOI values and citations intact unless a standard target-language form is clearly required.
            - For Persian output, use fluent contemporary Persian and correct Persian characters ی and ک.
            - If a specialized term has no safe established equivalent, keep the original technical term in parentheses after the best target-language equivalent.
            - Do not summarize, omit, embellish, explain or answer the text. Translate only.
            - Preserve each JSON item's id and translate its text independently while using the other items as context.
        """.trimIndent()
    }

    private fun extractOutputText(root: JSONObject): String {
        root.optString("output_text").takeIf { it.isNotBlank() }?.let { return it }
        val output = root.optJSONArray("output") ?: error("پاسخ سرویس ترجمه قابل خواندن نبود.")
        val pieces = mutableListOf<String>()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                if (part.optString("type") == "output_text") {
                    part.optString("text").takeIf { it.isNotBlank() }?.let(pieces::add)
                }
            }
        }
        return pieces.joinToString("\n").ifBlank { error("متن ترجمه در پاسخ سرویس پیدا نشد.") }
    }
}
