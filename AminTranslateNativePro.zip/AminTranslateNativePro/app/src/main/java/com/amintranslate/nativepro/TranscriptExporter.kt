package com.amintranslate.nativepro

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TranscriptExporter {
    fun saveTxt(context: Context, prefix: String, sourceText: String, translatedText: String): String {
        val body = buildString {
            appendLine("AminTranslate Native Pro")
            appendLine("========================")
            appendLine()
            appendLine("SOURCE")
            appendLine(sourceText)
            if (translatedText.isNotBlank()) {
                appendLine()
                appendLine("TRANSLATION")
                appendLine(translatedText)
            }
        }
        return save(context, "${prefix}_${stamp()}.txt", "text/plain", body)
    }

    fun saveSrt(context: Context, prefix: String, cues: List<SubtitleCue>, translatedFirst: Boolean = true): String {
        require(cues.isNotEmpty()) { "زیرنویس زمان‌دار برای ذخیره وجود ندارد." }
        val body = buildString {
            cues.forEachIndexed { index, cue ->
                appendLine(index + 1)
                append(formatSrtTime(cue.startMs))
                append(" --> ")
                appendLine(formatSrtTime(cue.endMs.coerceAtLeast(cue.startMs + 500)))
                if (translatedFirst && cue.translatedText.isNotBlank()) appendLine(cue.translatedText.trim())
                if (cue.sourceText.isNotBlank()) appendLine(cue.sourceText.trim())
                appendLine()
            }
        }
        return save(context, "${prefix}_${stamp()}.srt", "application/x-subrip", body)
    }

    private fun save(context: Context, fileName: String, mime: String, content: String): String {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AminTranslate")
        }
        val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("ساخت فایل خروجی ممکن نشد.")
        context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8).use { writer ->
            requireNotNull(writer) { "نوشتن فایل خروجی ممکن نشد." }
            writer.write(content)
        }
        return "Downloads/AminTranslate/$fileName"
    }

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun formatSrtTime(ms: Long): String {
        val total = ms.coerceAtLeast(0)
        val h = total / 3_600_000
        val m = (total % 3_600_000) / 60_000
        val s = (total % 60_000) / 1_000
        val milli = total % 1_000
        return "%02d:%02d:%02d,%03d".format(Locale.US, h, m, s, milli)
    }
}
