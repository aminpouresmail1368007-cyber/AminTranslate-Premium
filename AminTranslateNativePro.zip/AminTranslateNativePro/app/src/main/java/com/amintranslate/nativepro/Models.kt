package com.amintranslate.nativepro

data class LanguageOption(
    val code: String,
    val labelFa: String,
    val labelEn: String
)

val supportedLanguages = listOf(
    LanguageOption("fa", "فارسی", "Persian"),
    LanguageOption("en", "انگلیسی", "English"),
    LanguageOption("ar", "عربی", "Arabic"),
    LanguageOption("tr", "ترکی", "Turkish"),
    LanguageOption("fr", "فرانسوی", "French"),
    LanguageOption("de", "آلمانی", "German"),
    LanguageOption("es", "اسپانیایی", "Spanish"),
    LanguageOption("it", "ایتالیایی", "Italian"),
    LanguageOption("ru", "روسی", "Russian"),
    LanguageOption("uk", "اوکراینی", "Ukrainian"),
    LanguageOption("pt", "پرتغالی", "Portuguese"),
    LanguageOption("hi", "هندی", "Hindi"),
    LanguageOption("ur", "اردو", "Urdu"),
    LanguageOption("ja", "ژاپنی", "Japanese"),
    LanguageOption("ko", "کره‌ای", "Korean"),
    LanguageOption("zh", "چینی", "Chinese")
)

data class HistoryEntry(
    val id: Long,
    val kind: String,
    val sourceCode: String,
    val targetCode: String,
    val input: String,
    val output: String,
    val createdAt: Long
)

data class SubtitleCue(
    val startMs: Long,
    val endMs: Long,
    val sourceText: String,
    val translatedText: String
)

data class SpeechSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

data class SpeechTranscription(
    val text: String,
    val segments: List<SpeechSegment>,
    val processingTimeMs: Long
)

data class AppUiState(
    val sourceLanguage: LanguageOption = supportedLanguages.first { it.code == "en" },
    val targetLanguage: LanguageOption = supportedLanguages.first { it.code == "fa" },
    val inputText: String = "",
    val outputText: String = "",
    val busy: Boolean = false,
    val status: String = "آماده برای ترجمه",
    val error: String? = null,
    val history: List<HistoryEntry> = emptyList(),
    val ocrLanguage: String = "fas+eng",
    val speechModel: String = "base",
    val detectedSpeechLanguage: String = "",
    val audioTranscript: String = "",
    val videoTranscript: String = "",
    val videoTranslation: String = "",
    val onlineVideoUrl: String = "",
    val onlineTranscript: String = "",
    val onlineSubtitles: List<SubtitleCue> = emptyList(),
    val darkMode: Boolean = true
)
