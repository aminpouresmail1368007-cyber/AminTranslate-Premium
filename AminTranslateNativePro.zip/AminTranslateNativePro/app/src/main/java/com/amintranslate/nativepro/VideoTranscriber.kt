package com.amintranslate.nativepro

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.nio.ByteBuffer

class VideoTranscriber(private val context: Context) {

    private data class VoskModelInfo(val folder: String, val url: String)

    private fun modelInfo(language: String): VoskModelInfo = when (language) {
        "fa" -> VoskModelInfo(
            "vosk-model-small-fa-0.42",
            "https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip"
        )
        else -> VoskModelInfo(
            "vosk-model-small-en-us-0.15",
            "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
        )
    }

    fun ensureModel(language: String, onStatus: (String) -> Unit): File {
        val info = modelInfo(language)
        val root = File(context.filesDir, "vosk")
        val modelDir = File(root, info.folder)
        if (File(modelDir, "am").exists() || File(modelDir, "conf").exists()) return modelDir

        root.mkdirs()
        val zip = File(context.cacheDir, "${info.folder}.zip")
        onStatus("در حال دریافت مدل گفتار ${if (language == "fa") "فارسی" else "انگلیسی"}…")
        DownloadUtils.download(info.url, zip) { p ->
            if (p % 5 == 0) onStatus("دانلود مدل گفتار: $p٪")
        }
        onStatus("در حال آماده‌سازی مدل گفتار…")
        DownloadUtils.unzip(zip, root)
        zip.delete()
        check(modelDir.exists()) { "فایل مدل گفتار پس از دانلود پیدا نشد." }
        return modelDir
    }

    fun transcribe(uri: Uri, language: String, onStatus: (String) -> Unit): String {
        val modelDir = ensureModel(language, onStatus)
        onStatus("در حال استخراج و تحلیل صدای ویدیو…")
        Model(modelDir.absolutePath).use { model ->
            return decodeAndRecognize(uri, model, onStatus)
        }
    }

    private fun decodeAndRecognize(uri: Uri, model: Model, onStatus: (String) -> Unit): String {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)

        var audioTrack = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME).orEmpty()
            if (mime.startsWith("audio/")) {
                audioTrack = i
                format = f
                break
            }
        }
        check(audioTrack >= 0 && format != null) { "این ویدیو ترک صوتی قابل پردازش ندارد." }
        extractor.selectTrack(audioTrack)

        val mime = format!!.getString(MediaFormat.KEY_MIME) ?: error("فرمت صوتی نامشخص است.")
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        var inputDone = false
        var outputDone = false
        var recognizer: Recognizer? = null
        val pieces = mutableListOf<String>()
        val info = MediaCodec.BufferInfo()
        var decodedBytes = 0L

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex) ?: continue
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(
                                inputIndex, 0, 0, 0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(
                                inputIndex, 0, sampleSize, extractor.sampleTime, 0
                            )
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val outFormat = codec.outputFormat
                        val sampleRate = outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        recognizer?.close()
                        recognizer = Recognizer(model, sampleRate.toFloat()).apply {
                            setWords(true)
                        }
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outputIndex >= 0) {
                        val buffer = codec.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val bytes = ByteArray(info.size)
                            buffer.get(bytes)
                            decodedBytes += bytes.size
                            val r = recognizer ?: Recognizer(
                                model,
                                (format!!.getInteger(MediaFormat.KEY_SAMPLE_RATE)).toFloat()
                            ).also {
                                it.setWords(true)
                                recognizer = it
                            }
                            if (r.acceptWaveForm(bytes, bytes.size)) {
                                val text = JSONObject(r.result).optString("text").trim()
                                if (text.isNotBlank()) pieces += text
                            }
                            if (decodedBytes % (1024 * 1024) < info.size) {
                                onStatus("در حال تبدیل گفتار ویدیو به متن…")
                            }
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }

            recognizer?.let { r ->
                val finalText = JSONObject(r.finalResult).optString("text").trim()
                if (finalText.isNotBlank()) pieces += finalText
            }
        } finally {
            recognizer?.close()
            codec.stop()
            codec.release()
            extractor.release()
        }

        return pieces.joinToString(" ").replace(Regex("\\s+"), " ").trim()
    }
}
