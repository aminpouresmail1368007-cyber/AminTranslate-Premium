package com.amintranslate.nativepro

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

class TranslationEngine {
    suspend fun translate(text: String, source: String, target: String): String {
        require(text.isNotBlank()) { "متن برای ترجمه خالی است." }
        if (source == target) return text
        return translateMany(listOf(text), source, target).first()
    }

    suspend fun translateMany(texts: List<String>, source: String, target: String): List<String> {
        if (texts.isEmpty()) return emptyList()
        if (source == target) return texts

        val sourceLang = TranslateLanguage.fromLanguageTag(source.substringBefore('-'))
            ?: error("ترجمه برای زبان مبدأ $source در موتور فعلی پشتیبانی نمی‌شود.")
        val targetLang = TranslateLanguage.fromLanguageTag(target.substringBefore('-'))
            ?: error("زبان مقصد پشتیبانی نمی‌شود: $target")

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()

        val translator = Translation.getClient(options)
        return try {
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            texts.map { item ->
                if (item.isBlank()) item else translator.translate(item).await()
            }
        } finally {
            translator.close()
        }
    }
}
