package com.amintranslate.nativepro

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

class TranslationEngine {
    suspend fun translate(text: String, source: String, target: String): String {
        require(text.isNotBlank()) { "متن برای ترجمه خالی است." }
        if (source == target) return text

        val sourceLang = TranslateLanguage.fromLanguageTag(source)
            ?: error("زبان مبدأ پشتیبانی نمی‌شود: $source")
        val targetLang = TranslateLanguage.fromLanguageTag(target)
            ?: error("زبان مقصد پشتیبانی نمی‌شود: $target")

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()

        val translator = Translation.getClient(options)
        return try {
            val conditions = DownloadConditions.Builder().build()
            translator.downloadModelIfNeeded(conditions).await()
            translator.translate(text).await()
        } finally {
            translator.close()
        }
    }
}
