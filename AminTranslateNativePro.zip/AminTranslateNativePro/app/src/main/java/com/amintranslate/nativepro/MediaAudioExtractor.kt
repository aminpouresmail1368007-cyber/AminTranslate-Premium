package com.amintranslate.nativepro

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MediaAudioExtractor(private val context: Context) {

    fun fromUri(uri: Uri, destination: File, onStatus: (String) -> Unit = {}): File {
        return decode(destination, onStatus) { extractor ->
            extractor.setDataSource(context, uri, null)
        }
    }

    fun fromUrl(url: String, destination: File, onStatus: (String) -> Unit = {}): File {
        require(url.startsWith("https://")) { "برای امنیت، لینک ویدیو باید با https:// شروع شود." }
        return decode(destination, onStatus) { extractor ->
            extractor.setDataSource(url, mapOf("User-Agent" to "AminTranslate/2.0 Android"))
        }
    }

    private fun decode(
        destination: File,
        onStatus: (String) -> Unit,
        setSource: (MediaExtractor) -> Unit
    ): File {
        destination.parentFile?.mkdirs()
        if (destination.exists()) destination.delete()

        val extractor = MediaExtractor()
        setSource(extractor)

        var audioTrack = -1
        var sourceFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME).orEmpty()
            if (mime.startsWith("audio/")) {
                audioTrack = i
                sourceFormat = f
                break
            }
        }
        check(audioTrack >= 0 && sourceFormat != null) { "ترک صوتی قابل پردازش پیدا نشد." }
        extractor.selectTrack(audioTrack)

        val mime = sourceFormat!!.getString(MediaFormat.KEY_MIME) ?: error("فرمت صوتی نامشخص است.")
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(sourceFormat, null, null, 0)
        codec.start()

        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var sampleRate = 0
        var channels = 0
        var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
        var globalSourceFrame = 0L
        var nextOutputSourceFrame = 0.0
        var writtenSamples = 0L
        var lastStatusBytes = 0L

        val writer = BufferedPcmWriter(destination)
        writer.open()

        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputIndex) ?: continue
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val out = codec.outputFormat
                        sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        pcmEncoding = if (out.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                            out.getInteger(MediaFormat.KEY_PCM_ENCODING)
                        } else AudioFormat.ENCODING_PCM_16BIT
                        check(channels > 0 && sampleRate > 0) { "مشخصات خروجی صدا نامعتبر است." }
                        onStatus("در حال تبدیل صدا به فرمت مناسب تشخیص گفتار…")
                    }
                    MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                    else -> if (outputIndex >= 0) {
                        val buffer = codec.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0) {
                            if (sampleRate == 0 || channels == 0) {
                                val out = codec.outputFormat
                                sampleRate = out.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                                channels = out.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            }
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val slice = buffer.slice().order(ByteOrder.LITTLE_ENDIAN)
                            val bytesPerSample = when (pcmEncoding) {
                                AudioFormat.ENCODING_PCM_FLOAT -> 4
                                AudioFormat.ENCODING_PCM_16BIT -> 2
                                else -> error("نوع PCM این فایل روی گوشی پشتیبانی نشد.")
                            }
                            val frameSize = bytesPerSample * channels
                            val frames = if (frameSize > 0) slice.remaining() / frameSize else 0
                            val sourcePerOutput = sampleRate.toDouble() / 16_000.0

                            repeat(frames) {
                                var sum = 0.0
                                repeat(channels) {
                                    sum += when (pcmEncoding) {
                                        AudioFormat.ENCODING_PCM_FLOAT -> slice.float.toDouble().coerceIn(-1.0, 1.0)
                                        else -> (slice.short.toDouble() / 32768.0).coerceIn(-1.0, 1.0)
                                    }
                                }
                                val mono = (sum / channels).coerceIn(-1.0, 1.0)
                                while (nextOutputSourceFrame <= globalSourceFrame.toDouble()) {
                                    writer.writeSample((mono * 32767.0).toInt().coerceIn(-32768, 32767).toShort())
                                    writtenSamples++
                                    nextOutputSourceFrame += sourcePerOutput
                                }
                                globalSourceFrame++
                            }

                            lastStatusBytes += info.size
                            if (lastStatusBytes >= 4L * 1024 * 1024) {
                                onStatus("در حال آماده‌سازی صدای ویدیو/فایل…")
                                lastStatusBytes = 0
                            }
                        }
                        outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
        } finally {
            runCatching { codec.stop() }
            codec.release()
            extractor.release()
            writer.closeAndPatch(writtenSamples)
        }

        check(destination.exists() && destination.length() > 44) { "خروجی صوتی قابل استفاده ساخته نشد." }
        return destination
    }

    private class BufferedPcmWriter(private val file: File) {
        private var stream: BufferedOutputStream? = null
        private val buffer = ByteArray(64 * 1024)
        private var pos = 0

        fun open() {
            stream = BufferedOutputStream(FileOutputStream(file), 64 * 1024)
            stream!!.write(ByteArray(44))
        }

        fun writeSample(sample: Short) {
            if (pos + 2 > buffer.size) flushBuffer()
            buffer[pos++] = (sample.toInt() and 0xFF).toByte()
            buffer[pos++] = ((sample.toInt() shr 8) and 0xFF).toByte()
        }

        private fun flushBuffer() {
            if (pos > 0) {
                stream?.write(buffer, 0, pos)
                pos = 0
            }
        }

        fun closeAndPatch(sampleCount: Long) {
            flushBuffer()
            stream?.flush()
            stream?.close()
            stream = null
            val dataSize = sampleCount * 2L
            val riffSize = 36L + dataSize
            RandomAccessFile(file, "rw").use { raf ->
                raf.seek(0)
                raf.writeBytes("RIFF")
                writeLeInt(raf, riffSize.toInt())
                raf.writeBytes("WAVE")
                raf.writeBytes("fmt ")
                writeLeInt(raf, 16)
                writeLeShort(raf, 1)
                writeLeShort(raf, 1)
                writeLeInt(raf, 16_000)
                writeLeInt(raf, 16_000 * 2)
                writeLeShort(raf, 2)
                writeLeShort(raf, 16)
                raf.writeBytes("data")
                writeLeInt(raf, dataSize.toInt())
            }
        }

        private fun writeLeInt(raf: RandomAccessFile, value: Int) {
            raf.write(value and 0xFF)
            raf.write(value shr 8 and 0xFF)
            raf.write(value shr 16 and 0xFF)
            raf.write(value shr 24 and 0xFF)
        }

        private fun writeLeShort(raf: RandomAccessFile, value: Int) {
            raf.write(value and 0xFF)
            raf.write(value shr 8 and 0xFF)
        }
    }
}
