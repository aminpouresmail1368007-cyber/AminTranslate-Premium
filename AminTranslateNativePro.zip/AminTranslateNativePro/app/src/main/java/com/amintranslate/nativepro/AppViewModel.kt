package com.amintranslate.nativepro

import android.app.Application
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val translator = TranslationEngine()
    private val historyStore = HistoryStore(application)
    private val ocrEngine = OcrEngine(application)
    private val videoTranscriber = VideoTranscriber(application)

    private val _state = MutableStateFlow(
        AppUiState(history = historyStore.load())
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    fun setInput(value: String) = _state.update { it.copy(inputText = value, error = null) }

    fun setSource(language: LanguageOption) = _state.update { it.copy(sourceLanguage = language, error = null) }
    fun setTarget(language: LanguageOption) = _state.update { it.copy(targetLanguage = language, error = null) }

    fun swapLanguages() = _state.update {
        it.copy(
            sourceLanguage = it.targetLanguage,
            targetLanguage = it.sourceLanguage,
            inputText = if (it.outputText.isNotBlank()) it.outputText else it.inputText,
            outputText = "",
            error = null
        )
    }

    fun translateCurrent(kind: String = "text") {
        val snapshot = _state.value
        if (snapshot.inputText.isBlank()) {
            _state.update { it.copy(error = "اول متن را وارد کن.") }
            return
        }
        runTranslation(snapshot.inputText, kind)
    }

    fun useVoiceResult(text: String) {
        if (text.isBlank()) {
            _state.update { it.copy(error = "صدایی تشخیص داده نشد.") }
            return
        }
        _state.update { it.copy(inputText = text, status = "گفتار دریافت شد؛ در حال ترجمه…", error = null) }
        runTranslation(text, "voice")
    }

    fun processImage(uri: Uri) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            setBusy("در حال آماده‌سازی OCR…")
            try {
                val recognized = withContext(Dispatchers.IO) {
                    ocrEngine.ensureModels(_state.value.ocrLanguage) { status -> setStatus(status) }
                    val bitmap = app.contentResolver.openInputStream(uri).use { stream ->
                        requireNotNull(stream) { "تصویر قابل خواندن نیست." }
                        BitmapFactory.decodeStream(stream)
                    } ?: error("تصویر قابل پردازش نیست.")
                    ocrEngine.recognize(bitmap, _state.value.ocrLanguage)
                }
                if (recognized.isBlank()) error("متنی در تصویر پیدا نشد.")
                _state.update { it.copy(inputText = recognized, status = "متن تصویر استخراج شد؛ در حال ترجمه…") }
                translateAndStore(recognized, "image")
            } catch (t: Throwable) {
                fail(t)
            }
        }
    }

    fun setOcrLanguage(value: String) = _state.update { it.copy(ocrLanguage = value) }
    fun setVideoSpeechLanguage(value: String) = _state.update { it.copy(videoSpeechLanguage = value) }

    fun processVideo(uri: Uri) {
        viewModelScope.launch {
            setBusy("در حال آماده‌سازی موتور ویدیو…")
            try {
                val speechLanguage = _state.value.videoSpeechLanguage
                val transcript = withContext(Dispatchers.IO) {
                    videoTranscriber.transcribe(uri, speechLanguage) { status -> setStatus(status) }
                }
                if (transcript.isBlank()) error("گفتاری از ویدیو استخراج نشد.")
                _state.update {
                    it.copy(
                        videoTranscript = transcript,
                        inputText = transcript,
                        status = "متن ویدیو آماده شد؛ در حال ترجمه…"
                    )
                }
                val target = _state.value.targetLanguage.code
                val translated = translator.translate(transcript, speechLanguage, target)
                _state.update {
                    it.copy(
                        outputText = translated,
                        videoTranslation = translated,
                        busy = false,
                        status = "ترجمه ویدیو کامل شد",
                        error = null
                    )
                }
                saveHistory("video", speechLanguage, target, transcript, translated)
            } catch (t: Throwable) {
                fail(t)
            }
        }
    }

    fun clearHistory() {
        historyStore.clear()
        _state.update { it.copy(history = emptyList(), status = "تاریخچه پاک شد") }
    }

    fun setDarkMode(enabled: Boolean) = _state.update { it.copy(darkMode = enabled) }

    private fun runTranslation(text: String, kind: String) {
        viewModelScope.launch {
            setBusy("در حال آماده‌سازی مدل ترجمه…")
            try {
                translateAndStore(text, kind)
            } catch (t: Throwable) {
                fail(t)
            }
        }
    }

    private suspend fun translateAndStore(text: String, kind: String) {
        val source = _state.value.sourceLanguage.code
        val target = _state.value.targetLanguage.code
        setStatus("در حال ترجمه ${_state.value.sourceLanguage.labelFa} → ${_state.value.targetLanguage.labelFa}…")
        val translated = translator.translate(text, source, target)
        _state.update {
            it.copy(
                outputText = translated,
                busy = false,
                status = "ترجمه با موفقیت انجام شد",
                error = null
            )
        }
        saveHistory(kind, source, target, text, translated)
    }

    private fun saveHistory(kind: String, source: String, target: String, input: String, output: String) {
        val entry = HistoryEntry(
            id = System.currentTimeMillis(),
            kind = kind,
            sourceCode = source,
            targetCode = target,
            input = input,
            output = output,
            createdAt = System.currentTimeMillis()
        )
        historyStore.save(entry)
        _state.update { it.copy(history = historyStore.load()) }
    }

    private fun setBusy(status: String) = _state.update { it.copy(busy = true, status = status, error = null) }
    private fun setStatus(status: String) = _state.update { it.copy(status = status) }

    private fun fail(t: Throwable) {
        _state.update {
            it.copy(
                busy = false,
                status = "عملیات متوقف شد",
                error = t.message ?: "خطای ناشناخته"
            )
        }
    }
}
