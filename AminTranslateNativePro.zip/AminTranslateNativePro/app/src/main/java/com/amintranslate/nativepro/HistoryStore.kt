package com.amintranslate.nativepro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("amintranslate_history", Context.MODE_PRIVATE)

    fun load(): List<HistoryEntry> {
        val raw = prefs.getString("items", "[]") ?: "[]"
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        HistoryEntry(
                            id = o.optLong("id"),
                            kind = o.optString("kind"),
                            sourceCode = o.optString("source"),
                            targetCode = o.optString("target"),
                            input = o.optString("input"),
                            output = o.optString("output"),
                            createdAt = o.optLong("createdAt")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(entry: HistoryEntry) {
        val items = (listOf(entry) + load()).take(100)
        write(items)
    }

    fun clear() = write(emptyList())

    private fun write(items: List<HistoryEntry>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(JSONObject().apply {
                put("id", item.id)
                put("kind", item.kind)
                put("source", item.sourceCode)
                put("target", item.targetCode)
                put("input", item.input)
                put("output", item.output)
                put("createdAt", item.createdAt)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
