package com.amintranslate.nativepro

import android.content.Context
import android.net.Uri
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class WhisperTranscriber(private val context: Context) {
    private val extractor = MediaAudioExtractor(context)

    private data class ModelInfo(val fileName: String, val url: String, val label: String)

    private fun modelInfo(model: String): ModelInfo = when (model) {
        "small" -> ModelInfo(
            "ggml-small.bin",
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin?download=true",
            "Whisper Small (دقیق‌تر)"
        )
        else -> ModelInfo(
            "ggml-base.bin",
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin?download=true",
            "Whisper Base"
        )
    }

    private suspend fun ensureModel(model: String, onStatus: (String) -> Unit): File = withContext(Dispatchers.IO) {
        val info = modelInfo(model)
        val dir = File(context.filesDir, "whisper").apply { mkdirs() }
        val modelFile = File(dir, info.fileName)
        val minSize = if (model == "small") 300L * 1024 * 1024 else 90L * 1024 * 1024
        if (modelFile.exists() && modelFile.length() > minSize) return@withContext modelFile

        if (modelFile.exists()) modelFile.delete()
        onStatus("در اولین استفاده، مدل ${info.label} دانلود می‌شود…")
        DownloadUtils.download(info.url, modelFile) { p ->
            if (p in 1..100 && p % 2 == 0) onStatus("دانلود مدل گفتار: $p٪")
        }
        check(modelFile.length() > minSize) { "دانلود مدل گفتار کامل نشد. دوباره تلاش کن." }
        modelFile
    }

    suspend fun transcribe(uri: Uri, model: String, onStatus: (String) -> Unit): SpeechTranscription {
        val wav = withContext(Dispatchers.IO) {
            val out = File(context.cacheDir, "speech_${System.currentTimeMillis()}.wav")
            extractor.fromUri(uri, out, onStatus)
        }
        return try {
            transcribeWav(wav, model, onStatus)
        } finally {
            wav.delete()
        }
    }

    suspend fun transcribeUrl(url: String, model: String, onStatus: (String) -> Unit): SpeechTranscription {
        val wav = withContext(Dispatchers.IO) {
            val out = File(context.cacheDir, "online_${System.currentTimeMillis()}.wav")
            extractor.fromUrl(url, out, onStatus)
        }
        return try {
            transcribeWav(wav, model, onStatus)
        } finally {
            wav.delete()
        }
    }

    private suspend fun transcribeWav(wav: File, modelName: String, onStatus: (String) -> Unit): SpeechTranscription {
        val modelFile = ensureModel(modelName, onStatus)
        onStatus("در حال تشخیص خودکار زبان و تبدیل صدا به متن…")
        val loaded = Whisper.loadModel(context, modelFile.absolutePath)
        return try {
            val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
            val result = Whisper.transcribe(
                loaded,
                wav.absolutePath,
                WhisperConfig(language = "auto", translate = false, threads = threads, printTimestamps = true)
            )
            SpeechTranscription(
                text = result.text,
                segments = result.segments.map { SpeechSegment(it.startMs, it.endMs, it.text) },
                processingTimeMs = result.processingTimeMs
            )
        } finally {
            Whisper.releaseModel(loaded)
        }
    }
}
