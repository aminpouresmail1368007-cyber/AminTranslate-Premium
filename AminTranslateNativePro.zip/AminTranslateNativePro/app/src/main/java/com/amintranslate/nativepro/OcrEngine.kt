package com.amintranslate.nativepro

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class OcrEngine(private val context: Context) {
    private val baseDir = File(context.filesDir, "tesseract")
    private val tessDataDir = File(baseDir, "tessdata")

    suspend fun ensureModels(languageExpression: String, onStatus: (String) -> Unit) {
        tessDataDir.mkdirs()
        languageExpression.split("+").distinct().forEach { lang ->
            val file = File(tessDataDir, "$lang.traineddata")
            if (!file.exists() || file.length() < 100_000) {
                val url = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$lang.traineddata"
                onStatus("در حال دریافت مدل OCR ${displayLanguage(lang)}…")
                DownloadUtils.download(url, file) { progress ->
                    if (progress % 10 == 0) onStatus("دانلود مدل OCR ${displayLanguage(lang)}: $progress٪")
                }
            }
        }
    }

    fun recognize(bitmap: Bitmap, languageExpression: String): String {
        val tess = TessBaseAPI()
        return try {
            val ok = tess.init(baseDir.absolutePath, languageExpression)
            check(ok) { "مدل OCR راه‌اندازی نشد." }
            tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            tess.setImage(bitmap)
            tess.getUTF8Text()?.trim().orEmpty()
        } finally {
            tess.recycle()
        }
    }

    private fun displayLanguage(code: String) = when (code) {
        "fas" -> "فارسی"
        "eng" -> "انگلیسی"
        else -> code
    }
}
