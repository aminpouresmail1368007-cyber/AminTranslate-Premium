package com.amintranslate.nativepro

import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object DownloadUtils {
    fun download(url: String, destination: File, onProgress: (Int) -> Unit = {}) {
        destination.parentFile?.mkdirs()
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 20_000
        connection.readTimeout = 60_000
        connection.instanceFollowRedirects = true
        connection.connect()
        if (connection.responseCode !in 200..299) {
            error("خطا در دانلود: HTTP ${connection.responseCode}")
        }
        val total = connection.contentLengthLong.coerceAtLeast(1L)
        connection.inputStream.use { input ->
            destination.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var read: Int
                var downloaded = 0L
                while (input.read(buffer).also { read = it } >= 0) {
                    if (read == 0) continue
                    output.write(buffer, 0, read)
                    downloaded += read
                    onProgress(((downloaded * 100) / total).toInt().coerceIn(0, 100))
                }
            }
        }
        connection.disconnect()
    }

    fun unzip(zipFile: File, destination: File) {
        destination.mkdirs()
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destination, entry.name)
                val canonicalDest = destination.canonicalFile
                val canonicalOut = outFile.canonicalFile
                require(canonicalOut.path.startsWith(canonicalDest.path)) { "Invalid zip entry" }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { output -> zis.copyTo(output) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
