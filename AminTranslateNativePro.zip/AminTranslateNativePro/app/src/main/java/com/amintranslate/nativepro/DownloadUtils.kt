package com.amintranslate.nativepro

import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object DownloadUtils {
    fun download(url: String, destination: File, onProgress: (Int) -> Unit = {}) {
        destination.parentFile?.mkdirs()
        val part = File(destination.parentFile, destination.name + ".part")
        if (part.exists()) part.delete()

        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 30_000
        connection.readTimeout = 120_000
        connection.instanceFollowRedirects = true
        connection.setRequestProperty("User-Agent", "AminTranslate/2.0 Android")
        connection.connect()
        if (connection.responseCode !in 200..299) {
            connection.disconnect()
            error("خطا در دانلود: HTTP ${connection.responseCode}")
        }

        val total = connection.contentLengthLong
        connection.inputStream.use { input ->
            part.outputStream().buffered(128 * 1024).use { output ->
                val buffer = ByteArray(128 * 1024)
                var downloaded = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    if (read == 0) continue
                    output.write(buffer, 0, read)
                    downloaded += read
                    if (total > 0) {
                        onProgress(((downloaded * 100L) / total).toInt().coerceIn(0, 100))
                    }
                }
            }
        }
        connection.disconnect()
        if (destination.exists()) destination.delete()
        check(part.renameTo(destination)) { "ذخیره فایل دانلودشده انجام نشد." }
        onProgress(100)
    }

    fun unzip(zipFile: File, destination: File) {
        destination.mkdirs()
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destination, entry.name)
                val canonicalDest = destination.canonicalFile
                val canonicalOut = outFile.canonicalFile
                require(canonicalOut.path.startsWith(canonicalDest.path)) { "Invalid zip entry" }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { output -> zis.copyTo(output) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
