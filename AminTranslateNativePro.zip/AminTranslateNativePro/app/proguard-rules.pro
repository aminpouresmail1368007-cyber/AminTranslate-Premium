# Keep JNI-facing speech/OCR wrappers intact in the minified share build.
-keep class dev.ffmpegkit.whisper.** { *; }
-keep class cz.adaptech.tesseract4android.** { *; }
-keepclasseswithmembernames class * { native <methods>; }

# Media3 / ML Kit ship their own consumer rules; these warnings are safe to ignore.
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
