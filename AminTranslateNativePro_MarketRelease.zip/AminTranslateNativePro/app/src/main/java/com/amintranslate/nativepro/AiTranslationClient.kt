package com.amintranslate.nativepro

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class AiTranslationClient {
    suspend fun translate(
        text: String,
        source: LanguageOption,
        target: LanguageOption,
        domain: TranslationDomain,
        apiKey: String,
        model: String
    ): String = translateMany(listOf(text), source, target, domain, apiKey, model).first()

    suspend fun translateMany(
        texts: List<String>,
        source: LanguageOption,
        target: LanguageOption,
        domain: TranslationDomain,
        apiKey: String,
        model: String
    ): List<String> = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "کلید API برای ترجمه AI تنظیم نشده است." }
        if (texts.isEmpty()) return@withContext emptyList()
        if (source.code == target.code) return@withContext texts

        val chosenModel = model.trim().ifBlank { "gpt-6-astra" }
        require(chosenModel.matches(Regex("[A-Za-z0-9._:-]{2,80}"))) { "نام مدل AI معتبر نیست." }

        val batches = batchTexts(texts)
        val all = mutableListOf<String>()
        for (batch in batches) {
            all += translateBatch(
                texts = batch,
                source = source,
                target = target,
                domain = domain,
                apiKey = apiKey,
                model = chosenModel
            )
        }
        all
    }

    private suspend fun translateBatch(
        texts: List<String>,
        source: LanguageOption,
        target: LanguageOption,
        domain: TranslationDomain,
        apiKey: String,
        model: String
    ): List<String> {
        val inputArray = JSONArray()
        texts.forEachIndexed { index, text ->
            inputArray.put(JSONObject().put("id", index).put("text", text))
        }

        val request = JSONObject()
            .put("model", model)
            .put("instructions", buildInstructions(source, target, domain))
            .put(
                "input",
                "Translate the JSON array below. Return ONLY a valid JSON array with the same ids and a field named translation. " +
                    "Do not add markdown or commentary.\n" + inputArray.toString()
            )
            .put("max_output_tokens", maxOf(1200, texts.sumOf { it.length } * 2).coerceAtMost(12000))

        var lastError: Throwable? = null
        repeat(3) { attempt ->
            try {
                val raw = executeRequest(request, apiKey)
                return parseTranslations(raw, texts.size)
            } catch (t: Throwable) {
                lastError = t
                if (attempt == 2 || !isRetryable(t)) throw t
                delay(750L * (attempt + 1))
            }
        }
        throw lastError ?: IllegalStateException("ترجمه AI انجام نشد.")
    }

    private fun batchTexts(texts: List<String>): List<List<String>> {
        val result = mutableListOf<MutableList<String>>()
        var current = mutableListOf<String>()
        var currentChars = 0
        val maxChars = 12_000
        val maxItems = 40

        texts.forEach { text ->
            val size = text.length.coerceAtLeast(1)
            if (current.isNotEmpty() && (current.size >= maxItems || currentChars + size > maxChars)) {
                result += current
                current = mutableListOf()
                currentChars = 0
            }
            current += text
            currentChars += size
        }
        if (current.isNotEmpty()) result += current
        return result
    }

    private fun executeRequest(request: JSONObject, apiKey: String): String {
        val connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 90_000
            doOutput = true
            setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "AminTranslate/4.2.2 Android")
        }

        try {
            connection.outputStream.use { it.write(request.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val raw = if (stream != null) {
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            } else ""

            if (code !in 200..299) {
                val message = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()
                throw AiHttpException(code, message?.takeIf { it.isNotBlank() } ?: "خطای سرویس ترجمه آنلاین: HTTP $code")
            }
            return extractOutputText(JSONObject(raw)).trim()
        } finally {
            connection.disconnect()
        }
    }

    private fun parseTranslations(outputText: String, expectedCount: Int): List<String> {
        val clean = outputText
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val start = clean.indexOf('[')
        val end = clean.lastIndexOf(']')
        require(start >= 0 && end > start) { "پاسخ AI ساختار ترجمه قابل خواندن نداشت." }

        val array = JSONArray(clean.substring(start, end + 1))
        val translatedById = mutableMapOf<Int, String>()
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            val id = item.optInt("id", -1)
            val translation = item.optString("translation").trim()
            if (id >= 0 && translation.isNotBlank()) translatedById[id] = translation
        }
        require(translatedById.size == expectedCount) { "پاسخ ترجمه AI ناقص بود؛ دوباره تلاش کن." }
        return (0 until expectedCount).map { index -> translatedById[index] ?: error("پاسخ ترجمه ناقص بود.") }
    }

    private fun isRetryable(t: Throwable): Boolean = when (t) {
        is AiHttpException -> t.code == 408 || t.code == 409 || t.code == 429 || t.code >= 500
        is java.net.SocketTimeoutException -> true
        is java.net.ConnectException -> true
        else -> false
    }

    private fun buildInstructions(source: LanguageOption, target: LanguageOption, domain: TranslationDomain): String {
        val domainPrompt = when (domain) {
            TranslationDomain.MEDICAL_LAB -> "medical, clinical laboratory, microbiology, immunology, pathology, molecular diagnostics and biomedical terminology"
            TranslationDomain.SCIENTIFIC_ACADEMIC -> "academic and scientific writing, research methods, statistics and publication terminology"
            TranslationDomain.ENGINEERING_IT -> "engineering, software, information technology, AI, data and cybersecurity terminology"
            TranslationDomain.LEGAL_BUSINESS -> "legal, administrative, management, finance and business terminology"
            TranslationDomain.GENERAL -> "general natural language"
            TranslationDomain.AUTO_EXPERT -> "automatically infer the subject domain and use the most authoritative professional terminology for it"
        }
        return """
            You are the high-precision professional translation engine inside AminTranslate.
            Translate from ${source.labelEn} (${source.code}) to ${target.labelEn} (${target.code}).
            Domain priority: $domainPrompt.
            Requirements:
            - Preserve meaning, register, tone, paragraph structure, numbers and negation exactly.
            - Use standard professional terminology, not literal word-by-word translation.
            - Resolve ambiguous terminology from surrounding context before choosing the target-language equivalent.
            - In specialist material, prefer terminology used in peer-reviewed literature, clinical guidelines, standards and professional practice.
            - Keep gene/protein names, organism names, drug names, abbreviations, units, formulas, URLs, DOI values and citations intact unless a standard target-language form is clearly required.
            - For Persian output, use fluent contemporary Persian and correct Persian characters ی and ک.
            - If a specialized term has no safe established equivalent, keep the original technical term in parentheses after the best target-language equivalent.
            - Do not summarize, omit, embellish, explain or answer the text. Translate only.
            - Preserve each JSON item's id and translate its text independently while using the other items as context.
        """.trimIndent()
    }

    private fun extractOutputText(root: JSONObject): String {
        root.optString("output_text").takeIf { it.isNotBlank() }?.let { return it }
        val output = root.optJSONArray("output") ?: error("پاسخ سرویس ترجمه قابل خواندن نبود.")
        val pieces = mutableListOf<String>()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val part = content.optJSONObject(j) ?: continue
                if (part.optString("type") == "output_text") {
                    part.optString("text").takeIf { it.isNotBlank() }?.let(pieces::add)
                }
            }
        }
        return pieces.joinToString("\n").ifBlank { error("متن ترجمه در پاسخ سرویس پیدا نشد.") }
    }

    private class AiHttpException(val code: Int, message: String) : IllegalStateException(message)
}
