package com.amintranslate.nativepro

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import dev.ffmpegkit.whisper.Whisper
import dev.ffmpegkit.whisper.WhisperConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class WhisperTranscriber(private val context: Context) {
    private val extractor = MediaAudioExtractor(context)

    private data class ModelInfo(
        val fileName: String,
        val url: String,
        val label: String,
        val minimumBytes: Long
    )

    private fun modelInfo(model: String): ModelInfo = when (model) {
        "tiny" -> ModelInfo(
            "ggml-tiny.bin",
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin",
            "Whisper Tiny (سریع)",
            55L * 1024 * 1024
        )
        "small" -> ModelInfo(
            "ggml-small.bin",
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.bin",
            "Whisper Small (دقیق‌تر)",
            300L * 1024 * 1024
        )
        else -> ModelInfo(
            "ggml-base.bin",
            "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin",
            "Whisper Base",
            90L * 1024 * 1024
        )
    }

    private suspend fun ensureModel(model: String, onStatus: (String) -> Unit): File = withContext(Dispatchers.IO) {
        if (model == "small") {
            val memoryInfo = ActivityManager.MemoryInfo()
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            activityManager.getMemoryInfo(memoryInfo)
            check(memoryInfo.totalMem >= 3L * 1024 * 1024 * 1024) {
                "برای پایداری، مدل Whisper Small روی گوشی‌های با کمتر از ۳ گیگابایت RAM فعال نمی‌شود. Base یا Tiny را انتخاب کن."
            }
        }
        val info = modelInfo(model)
        val dir = File(context.filesDir, "whisper").apply { mkdirs() }
        val modelFile = File(dir, info.fileName)
        if (modelFile.exists() && modelFile.length() > info.minimumBytes) return@withContext modelFile

        if (modelFile.exists()) modelFile.delete()
        onStatus("اولین اجرا: در حال دانلود ${info.label}. این مرحله فقط یک‌بار انجام می‌شود…")
        DownloadUtils.download(info.url, modelFile) { p ->
            if (p == 100 || (p in 1..99 && p % 2 == 0)) onStatus("دانلود مدل گفتار: $p٪")
        }
        check(modelFile.length() > info.minimumBytes) { "دانلود مدل گفتار کامل نشد. دوباره تلاش کن." }
        modelFile
    }

    suspend fun transcribe(uri: Uri, model: String, onStatus: (String) -> Unit): SpeechTranscription {
        val wav = withContext(Dispatchers.IO) {
            val out = File(context.cacheDir, "speech_${System.currentTimeMillis()}.wav")
            extractor.fromUri(uri, out, onStatus)
        }
        return try {
            transcribeWav(wav, model, onStatus)
        } finally {
            wav.delete()
        }
    }

    suspend fun transcribeUrl(url: String, model: String, onStatus: (String) -> Unit): SpeechTranscription {
        require(url.startsWith("https://")) { "لینک باید امن و با https:// باشد." }
        val stamp = System.currentTimeMillis()
        val sourceFile = File(context.cacheDir, "online_source_$stamp.media")
        val wav = File(context.cacheDir, "online_$stamp.wav")
        return try {
            withContext(Dispatchers.IO) {
                onStatus("در حال دریافت فایل رسانه‌ای…")
                DownloadUtils.download(url, sourceFile) { p ->
                    if (p == 100 || p % 5 == 0) onStatus("دریافت رسانه: $p٪")
                }
                extractor.fromFile(sourceFile, wav, onStatus)
            }
            transcribeWav(wav, model, onStatus)
        } finally {
            sourceFile.delete()
            wav.delete()
        }
    }

    private suspend fun transcribeWav(wav: File, modelName: String, onStatus: (String) -> Unit): SpeechTranscription {
        check(wav.exists() && wav.length() > 44) { "فایل صوتی آماده‌شده معتبر نیست." }
        val seconds = ((wav.length() - 44).coerceAtLeast(0) / 32_000.0)
        check(seconds <= 7_200) { "برای پایداری گوشی، فایل‌های طولانی‌تر از ۲ ساعت در یک مرحله پردازش نمی‌شوند." }

        val modelFile = ensureModel(modelName, onStatus)
        onStatus("در حال تشخیص خودکار زبان و تبدیل صدا به متن…")

        // Native Whisper inference is CPU-heavy. Never run it on the ViewModel/Main thread,
        // otherwise a long audio/video can freeze the UI and trigger an Android ANR.
        return withContext(Dispatchers.Default) {
            val loaded = try {
                Whisper.loadModel(context, modelFile.absolutePath)
            } catch (oom: OutOfMemoryError) {
                error("حافظه گوشی برای این مدل Whisper کافی نیست. مدل Tiny را انتخاب کن.")
            }

            try {
                val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
                val result = try {
                    Whisper.transcribe(
                        loaded,
                        wav.absolutePath,
                        WhisperConfig(language = "auto", translate = false, threads = threads, printTimestamps = true)
                    )
                } catch (oom: OutOfMemoryError) {
                    error("حافظه گوشی هنگام پردازش صدا کافی نبود. مدل Tiny یا فایل کوتاه‌تر را امتحان کن.")
                }
                SpeechTranscription(
                    text = result.text.trim(),
                    segments = result.segments.map { SpeechSegment(it.startMs, it.endMs, it.text.trim()) }.filter { it.text.isNotBlank() },
                    processingTimeMs = result.processingTimeMs
                )
            } finally {
                Whisper.releaseModel(loaded)
            }
        }
    }
}
