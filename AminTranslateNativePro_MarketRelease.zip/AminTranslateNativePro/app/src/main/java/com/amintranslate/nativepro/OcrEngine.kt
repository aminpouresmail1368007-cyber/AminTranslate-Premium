package com.amintranslate.nativepro

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import kotlin.math.roundToInt

class OcrEngine(private val context: Context) {
    private val baseDir = File(context.filesDir, "tesseract_best_v3")
    private val tessDataDir = File(baseDir, "tessdata")
    private val supported = setOf("fas", "eng")

    suspend fun ensureModels(languageExpression: String, onStatus: (String) -> Unit) {
        tessDataDir.mkdirs()
        val languages = languageExpression.split("+").map { it.trim() }.filter { it.isNotBlank() }.distinct()
        require(languages.isNotEmpty() && languages.all { it in supported }) {
            "زبان OCR انتخاب‌شده پشتیبانی نمی‌شود."
        }

        languages.forEach { lang ->
            val file = File(tessDataDir, "$lang.traineddata")
            if (!file.exists() || file.length() < 100_000) {
                val url = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_best/main/$lang.traineddata"
                onStatus("در حال دریافت مدل دقیق OCR ${displayLanguage(lang)}…")
                DownloadUtils.download(url, file) { progress ->
                    if (progress == 100 || progress % 10 == 0) {
                        onStatus("دانلود مدل دقیق OCR ${displayLanguage(lang)}: $progress٪")
                    }
                }
                check(file.exists() && file.length() >= 100_000) {
                    "دانلود مدل OCR ${displayLanguage(lang)} کامل نشد."
                }
            }
        }
    }

    fun recognize(bitmap: Bitmap, languageExpression: String): String {
        require(bitmap.width > 0 && bitmap.height > 0) { "تصویر نامعتبر است." }

        val prepared = upscaleIfNeeded(bitmap)
        val bitmapCandidates = buildBitmapCandidates(prepared)
        val languageCandidates = buildLanguageCandidates(languageExpression)
        var bestText = ""
        var bestScore = Int.MIN_VALUE

        try {
            languageCandidates.forEach { lang ->
                val tess = TessBaseAPI()
                try {
                    if (!tess.init(baseDir.absolutePath, lang)) return@forEach
                    runCatching { tess.setVariable("preserve_interword_spaces", "1") }
                    runCatching { tess.setVariable("user_defined_dpi", "300") }
                    runCatching { tess.setVariable("load_system_dawg", "1") }
                    runCatching { tess.setVariable("load_freq_dawg", "1") }

                    val modes = listOf(
                        TessBaseAPI.PageSegMode.PSM_AUTO,
                        TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK
                    )

                    bitmapCandidates.forEach { candidate ->
                        modes.forEach { mode ->
                            val raw = runCatching {
                                tess.setPageSegMode(mode)
                                tess.setImage(candidate.bitmap)
                                tess.getUTF8Text().orEmpty()
                            }.getOrDefault("")

                            val cleaned = cleanOcrText(raw)
                            if (cleaned.isNotBlank()) {
                                val score = qualityScore(cleaned, lang, candidate.isCropped)
                                if (score > bestScore) {
                                    bestScore = score
                                    bestText = cleaned
                                }
                            }
                        }
                    }
                } finally {
                    tess.recycle()
                }
            }
        } finally {
            bitmapCandidates.filter { it.shouldRecycle }.forEach { runCatching { it.bitmap.recycle() } }
            if (prepared !== bitmap) prepared.recycle()
        }

        return bestText.trim()
    }

    private data class BitmapCandidate(
        val bitmap: Bitmap,
        val isCropped: Boolean,
        val shouldRecycle: Boolean
    )

    private fun buildBitmapCandidates(bitmap: Bitmap): List<BitmapCandidate> {
        val result = mutableListOf(BitmapCandidate(bitmap, isCropped = false, shouldRecycle = false))
        val portraitLike = bitmap.height >= bitmap.width * 1.25f
        if (!portraitLike || bitmap.height < 900) return result

        // Mobile screenshots often contain a browser/status bar at the top and navigation bar at the bottom.
        // OCRing a second, safely cropped candidate prevents those controls from contaminating translation.
        val left = (bitmap.width * 0.015f).roundToInt().coerceAtLeast(0)
        val top = (bitmap.height * 0.105f).roundToInt().coerceAtLeast(0)
        val rightInset = (bitmap.width * 0.015f).roundToInt().coerceAtLeast(0)
        val bottomInset = (bitmap.height * 0.035f).roundToInt().coerceAtLeast(0)
        val width = (bitmap.width - left - rightInset).coerceAtLeast(1)
        val height = (bitmap.height - top - bottomInset).coerceAtLeast(1)

        if (width >= bitmap.width / 2 && height >= bitmap.height / 2) {
            runCatching { Bitmap.createBitmap(bitmap, left, top, width, height) }
                .getOrNull()
                ?.let { result += BitmapCandidate(it, isCropped = true, shouldRecycle = true) }
        }
        return result
    }

    private fun buildLanguageCandidates(requested: String): List<String> {
        val parts = requested.split("+").map { it.trim() }.filter { it in supported }.distinct()
        if (parts.size <= 1) return parts.ifEmpty { listOf("eng") }

        // Single-language OCR is considerably cleaner on monolingual screenshots.
        // Keep the mixed model as a fallback for genuinely bilingual material.
        val ordered = linkedSetOf<String>()
        if ("eng" in parts) ordered += "eng"
        if ("fas" in parts) ordered += "fas"
        ordered += parts.joinToString("+")
        return ordered.toList()
    }

    private fun upscaleIfNeeded(bitmap: Bitmap): Bitmap {
        val shortest = minOf(bitmap.width, bitmap.height)
        if (shortest >= 1200) return bitmap
        val scale = (1200f / shortest.coerceAtLeast(1)).coerceIn(1f, 2.2f)
        if (scale <= 1.05f) return bitmap
        return Bitmap.createScaledBitmap(
            bitmap,
            (bitmap.width * scale).toInt().coerceAtLeast(1),
            (bitmap.height * scale).toInt().coerceAtLeast(1),
            true
        )
    }

    private fun cleanOcrText(raw: String): String {
        if (raw.isBlank()) return ""
        val normalized = raw
            .replace('\u00A0', ' ')
            .replace("\r\n", "\n")
            .replace('\r', '\n')
            .replace("ي", "ی")
            .replace("ك", "ک")

        val urlRegex = Regex("(?i)(https?://|www\\.|[A-Za-z0-9-]+\\.(?:com|net|org|ir|io|edu|gov)(?:/|\\b))")
        val statusRegex = Regex("(?i)^(?:\\s*[0-2]?\\d[:.]\\d{2}\\s*)?(?:4G|5G|LTE|VoLTE|Wi[- ]?Fi|NFC|VPN|Bluetooth|battery|\\d{1,3}%)(?:\\s+.*)?$")
        val researchUiRegex = Regex("(?i)^(question|answer|asked\\s+[A-Z][a-z]+\\s+\\d{1,2}|follow|share|recommend|researchgate(?:\\.net)?)$")

        val kept = normalized.lines().map { line ->
            line.replace(Regex("[ \\t]+"), " ").trim()
        }.filterNot { line ->
            if (line.isBlank()) return@filterNot false
            if (urlRegex.containsMatchIn(line)) return@filterNot true
            if (researchUiRegex.matches(line)) return@filterNot true
            if (statusRegex.matches(line) && line.length < 60) return@filterNot true
            looksLikeToolbarNoise(line)
        }

        // Preserve paragraph breaks but collapse repeated blank rows.
        val compact = mutableListOf<String>()
        kept.forEach { line ->
            if (line.isBlank()) {
                if (compact.lastOrNull()?.isNotBlank() == true) compact += ""
            } else {
                compact += line
            }
        }
        while (compact.firstOrNull()?.isBlank() == true) compact.removeAt(0)
        while (compact.lastOrNull()?.isBlank() == true) compact.removeAt(compact.lastIndex)

        val joined = joinWrappedLines(compact)
        return joined
            .replace(Regex("[ \\t]+"), " ")
            .replace(Regex(" *\\n *"), "\n")
            .replace(Regex("\\n{3,}"), "\n\n")
            .trim()
    }

    private fun joinWrappedLines(lines: List<String>): String {
        if (lines.isEmpty()) return ""
        val out = StringBuilder()
        var paragraph = StringBuilder()

        fun flush() {
            if (paragraph.isNotBlank()) {
                if (out.isNotEmpty()) out.append("\n\n")
                out.append(paragraph.toString().trim())
                paragraph = StringBuilder()
            }
        }

        lines.forEach { line ->
            if (line.isBlank()) {
                flush()
                return@forEach
            }

            if (paragraph.isNotEmpty()) paragraph.append(' ')
            paragraph.append(line)

            val trimmed = line.trim()
            val endsSentence = trimmed.lastOrNull() in listOf('.', '!', '?', '؟', '؛')
            val looksLikeField = Regex("^[A-Za-z][A-Za-z /_-]{1,40}:\\s*.+").matches(trimmed)
            val standaloneHeading = trimmed.length <= 44 && trimmed.count { it.isLetter() } >= 4 &&
                trimmed.split(Regex("\\s+")).size <= 6 && trimmed.endsWith(":")

            if (endsSentence || looksLikeField || standaloneHeading) flush()
        }
        flush()
        return out.toString()
    }

    private fun looksLikeToolbarNoise(line: String): Boolean {
        if (line.length > 90) return false
        val letters = line.count { it.isLetter() || it in '\u0600'..'\u06FF' }
        val digits = line.count { it.isDigit() }
        val symbols = line.count { !it.isLetterOrDigit() && !it.isWhitespace() && it !in ".,،؛:!?؟()-/%+" }
        val tokens = line.split(Regex("\\s+")).filter { it.isNotBlank() }

        if (letters == 0 && digits > 0) return true
        if (symbols >= 3 && letters < 8) return true
        if (digits >= 4 && letters < 12 && tokens.size <= 8) return true
        if (tokens.size <= 3 && line.count { it == ':' } >= 1 && digits >= 2 && letters < 4) return true
        return false
    }

    private fun qualityScore(text: String, languageExpression: String, isCropped: Boolean): Int {
        val letters = text.count { it.isLetter() || it in '\u0600'..'\u06FF' }
        val digits = text.count { it.isDigit() }
        val words = text.split(Regex("\\s+")).count { token -> token.count { it.isLetter() } >= 2 }
        val sentenceMarks = text.count { it in ".!?؟" }
        val latin = text.count { it in 'A'..'Z' || it in 'a'..'z' }
        val persian = text.count { it in '\u0600'..'\u06FF' }
        val odd = text.count { ch ->
            !ch.isLetterOrDigit() && !ch.isWhitespace() && ch !in ".,،؛:!?؟()-/%+_'\"[]{}µ°"
        }

        var score = letters + words * 7 + sentenceMarks * 9 + digits
        score -= odd * 12
        score -= Regex("(?i)(https?://|www\\.|\\.(?:com|net|org|ir)\\b)").findAll(text).count() * 220
        score -= Regex("(?m)^.*(?:4G|5G|LTE|Wi[- ]?Fi|battery|\\d{1,2}:\\d{2}).*$", RegexOption.IGNORE_CASE)
            .findAll(text).count() * 90

        val totalScriptLetters = (latin + persian).coerceAtLeast(1)
        if (languageExpression == "eng") {
            score += ((latin.toDouble() / totalScriptLetters) * 220).toInt()
        } else if (languageExpression == "fas") {
            score += ((persian.toDouble() / totalScriptLetters) * 220).toInt()
        }

        if (isCropped) score += 80
        return score
    }

    private fun displayLanguage(code: String) = when (code) {
        "fas" -> "فارسی"
        "eng" -> "انگلیسی"
        else -> code
    }
}
