package com.amintranslate.nativepro

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class OcrEngine(private val context: Context) {
    private val baseDir = File(context.filesDir, "tesseract")
    private val tessDataDir = File(baseDir, "tessdata")
    private val supported = setOf("fas", "eng")

    suspend fun ensureModels(languageExpression: String, onStatus: (String) -> Unit) {
        tessDataDir.mkdirs()
        val languages = languageExpression.split("+").map { it.trim() }.filter { it.isNotBlank() }.distinct()
        require(languages.isNotEmpty() && languages.all { it in supported }) {
            "زبان OCR انتخاب‌شده پشتیبانی نمی‌شود."
        }

        languages.forEach { lang ->
            val file = File(tessDataDir, "$lang.traineddata")
            if (!file.exists() || file.length() < 100_000) {
                val url = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$lang.traineddata"
                onStatus("در حال دریافت مدل OCR ${displayLanguage(lang)}…")
                DownloadUtils.download(url, file) { progress ->
                    if (progress == 100 || progress % 10 == 0) {
                        onStatus("دانلود مدل OCR ${displayLanguage(lang)}: $progress٪")
                    }
                }
                check(file.exists() && file.length() >= 100_000) {
                    "دانلود مدل OCR ${displayLanguage(lang)} کامل نشد."
                }
            }
        }
    }

    fun recognize(bitmap: Bitmap, languageExpression: String): String {
        require(bitmap.width > 0 && bitmap.height > 0) { "تصویر نامعتبر است." }
        val tess = TessBaseAPI()
        return try {
            val ok = tess.init(baseDir.absolutePath, languageExpression)
            check(ok) { "مدل OCR راه‌اندازی نشد." }
            tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
            tess.setImage(bitmap)
            tess.getUTF8Text()?.trim().orEmpty()
        } finally {
            tess.recycle()
        }
    }

    private fun displayLanguage(code: String) = when (code) {
        "fas" -> "فارسی"
        "eng" -> "انگلیسی"
        else -> code
    }
}
