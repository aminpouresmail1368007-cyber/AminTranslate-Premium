package com.amintranslate.nativepro

import android.content.Context
import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class OcrEngine(private val context: Context) {
    private val baseDir = File(context.filesDir, "tesseract_best_v2")
    private val tessDataDir = File(baseDir, "tessdata")
    private val supported = setOf("fas", "eng")

    suspend fun ensureModels(languageExpression: String, onStatus: (String) -> Unit) {
        tessDataDir.mkdirs()
        val languages = languageExpression.split("+").map { it.trim() }.filter { it.isNotBlank() }.distinct()
        require(languages.isNotEmpty() && languages.all { it in supported }) {
            "زبان OCR انتخاب‌شده پشتیبانی نمی‌شود."
        }

        languages.forEach { lang ->
            val file = File(tessDataDir, "$lang.traineddata")
            if (!file.exists() || file.length() < 100_000) {
                // tessdata_best is slower than tessdata_fast, but noticeably more accurate for screenshots,
                // documents and mixed Persian/English text. Accuracy is the priority in the store build.
                val url = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_best/main/$lang.traineddata"
                onStatus("در حال دریافت مدل دقیق OCR ${displayLanguage(lang)}…")
                DownloadUtils.download(url, file) { progress ->
                    if (progress == 100 || progress % 10 == 0) {
                        onStatus("دانلود مدل دقیق OCR ${displayLanguage(lang)}: $progress٪")
                    }
                }
                check(file.exists() && file.length() >= 100_000) {
                    "دانلود مدل OCR ${displayLanguage(lang)} کامل نشد."
                }
            }
        }
    }

    fun recognize(bitmap: Bitmap, languageExpression: String): String {
        require(bitmap.width > 0 && bitmap.height > 0) { "تصویر نامعتبر است." }
        val prepared = upscaleIfNeeded(bitmap)
        val tess = TessBaseAPI()
        return try {
            val ok = tess.init(baseDir.absolutePath, languageExpression)
            check(ok) { "مدل OCR راه‌اندازی نشد." }
            runCatching { tess.setVariable("preserve_interword_spaces", "1") }
            runCatching { tess.setVariable("user_defined_dpi", "300") }

            // Layout differs greatly between a photo, screenshot and scanned document.
            // Try several safe segmentation modes and keep the most plausible result.
            val modes = listOf(
                TessBaseAPI.PageSegMode.PSM_AUTO,
                TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK,
                TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT
            )
            val candidates = modes.mapNotNull { mode ->
                runCatching {
                    tess.setPageSegMode(mode)
                    tess.setImage(prepared)
                    tess.getUTF8Text()?.trim().orEmpty()
                }.getOrNull()?.takeIf { it.isNotBlank() }
            }
            candidates.maxByOrNull(::qualityScore).orEmpty()
        } finally {
            tess.recycle()
            if (prepared !== bitmap) prepared.recycle()
        }
    }

    private fun upscaleIfNeeded(bitmap: Bitmap): Bitmap {
        val shortest = minOf(bitmap.width, bitmap.height)
        if (shortest >= 1200) return bitmap
        val scale = (1200f / shortest.coerceAtLeast(1)).coerceIn(1f, 2.2f)
        if (scale <= 1.05f) return bitmap
        return Bitmap.createScaledBitmap(
            bitmap,
            (bitmap.width * scale).toInt().coerceAtLeast(1),
            (bitmap.height * scale).toInt().coerceAtLeast(1),
            true
        )
    }

    private fun qualityScore(text: String): Int {
        val useful = text.count { ch ->
            ch.isLetterOrDigit() || ch in '\u0600'..'\u06FF' || ch.isWhitespace() || ch in ".,،؛:!?؟()-/%+"
        }
        val suspicious = text.count { ch -> ch.code in 0..31 && ch !in "\n\r\t" }
        val words = text.split(Regex("\\s+")).count { it.length >= 2 }
        return useful + words * 4 - suspicious * 20
    }

    private fun displayLanguage(code: String) = when (code) {
        "fas" -> "فارسی"
        "eng" -> "انگلیسی"
        else -> code
    }
}
