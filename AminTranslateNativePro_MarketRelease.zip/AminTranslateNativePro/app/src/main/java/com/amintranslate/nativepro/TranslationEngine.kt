package com.amintranslate.nativepro

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

class TranslationEngine {
    companion object {
        private const val MODEL_DOWNLOAD_TIMEOUT_MS = 90_000L
        private const val TRANSLATION_TIMEOUT_MS = 45_000L
        private const val SAFE_CHUNK_CHARS = 3_500
    }

    suspend fun translate(
        text: String,
        source: String,
        target: String,
        domain: TranslationDomain = TranslationDomain.AUTO_EXPERT,
        onStatus: (String) -> Unit = {}
    ): String {
        require(text.isNotBlank()) { "متن برای ترجمه خالی است." }
        if (source == target) return text
        return translateMany(listOf(text), source, target, domain, onStatus).first()
    }

    suspend fun translateMany(
        texts: List<String>,
        source: String,
        target: String,
        domain: TranslationDomain = TranslationDomain.AUTO_EXPERT,
        onStatus: (String) -> Unit = {}
    ): List<String> {
        if (texts.isEmpty()) return emptyList()
        if (source == target) return texts

        val sourceLang = TranslateLanguage.fromLanguageTag(source.substringBefore('-'))
            ?: error("ترجمه برای زبان مبدأ $source در موتور فعلی پشتیبانی نمی‌شود.")
        val targetLang = TranslateLanguage.fromLanguageTag(target.substringBefore('-'))
            ?: error("زبان مقصد پشتیبانی نمی‌شود: $target")

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()

        val translator = Translation.getClient(options)
        return try {
            ensureModelReady(translator, source, target, onStatus)
            val total = texts.size
            texts.mapIndexed { index, item ->
                if (item.isBlank()) {
                    item
                } else {
                    if (total > 1) onStatus("در حال ترجمه بخش ${index + 1} از $total…")
                    translateLongText(translator, item, source, target, domain, onStatus)
                }
            }
        } finally {
            translator.close()
        }
    }

    private suspend fun ensureModelReady(
        translator: Translator,
        source: String,
        target: String,
        onStatus: (String) -> Unit
    ) {
        onStatus("در حال آماده‌سازی مدل ترجمه ${source.uppercase()} → ${target.uppercase()}…")
        try {
            withTimeout(MODEL_DOWNLOAD_TIMEOUT_MS) {
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            }
        } catch (_: TimeoutCancellationException) {
            error(
                "آماده‌سازی مدل ترجمه بیش از ۹۰ ثانیه طول کشید. اینترنت را بررسی کن و دوباره تلاش کن؛ برنامه دیگر روی «در حال ترجمه» بی‌نهایت نمی‌ماند."
            )
        } catch (t: Throwable) {
            if (t is CancellationException) throw t
            val message = t.message.orEmpty()
            error(
                if (message.isNotBlank()) "مدل ترجمه آماده نشد: $message"
                else "مدل ترجمه آماده نشد. اینترنت را بررسی کن و دوباره تلاش کن."
            )
        }
    }

    private suspend fun translateLongText(
        translator: Translator,
        text: String,
        source: String,
        target: String,
        domain: TranslationDomain,
        onStatus: (String) -> Unit
    ): String {
        val chunks = chunkText(text)
        if (chunks.size == 1) return translateChunk(translator, chunks.first(), source, target, domain)

        val translated = chunks.mapIndexed { index, chunk ->
            onStatus("در حال ترجمه متن طولانی؛ بخش ${index + 1} از ${chunks.size}…")
            translateChunk(translator, chunk, source, target, domain)
        }
        return translated.joinToString("\n\n").replace(Regex("\n{3,}"), "\n\n").trim()
    }

    private suspend fun translateChunk(
        translator: Translator,
        text: String,
        source: String,
        target: String,
        domain: TranslationDomain
    ): String {
        val prepared = TechnicalGlossary.prepare(text, source, target, domain)
        val raw = try {
            withTimeout(TRANSLATION_TIMEOUT_MS) {
                translator.translate(prepared.text).await()
            }
        } catch (_: TimeoutCancellationException) {
            error("ترجمه این بخش بیش از ۴۵ ثانیه طول کشید. دوباره تلاش کن یا متن را کوتاه‌تر کن.")
        }
        return prepared.restore(raw)
    }

    private fun chunkText(text: String): List<String> {
        val normalized = text.trim()
        if (normalized.length <= SAFE_CHUNK_CHARS) return listOf(normalized)

        val paragraphs = normalized.split(Regex("\\n\\s*\\n"))
        val chunks = mutableListOf<String>()
        val current = StringBuilder()

        fun flush() {
            if (current.isNotBlank()) {
                chunks += current.toString().trim()
                current.clear()
            }
        }

        paragraphs.forEach { paragraph ->
            val p = paragraph.trim()
            if (p.isEmpty()) return@forEach

            if (p.length > SAFE_CHUNK_CHARS) {
                flush()
                var start = 0
                while (start < p.length) {
                    var end = (start + SAFE_CHUNK_CHARS).coerceAtMost(p.length)
                    if (end < p.length) {
                        val boundary = p.lastIndexOfAny(charArrayOf('.', '!', '?', '؟', '؛', ';', '。'), startIndex = (end - 1).coerceAtLeast(start))
                        if (boundary > start + SAFE_CHUNK_CHARS / 2) end = boundary + 1
                    }
                    chunks += p.substring(start, end).trim()
                    start = end
                }
            } else {
                val separator = if (current.isEmpty()) "" else "\n\n"
                if (current.length + separator.length + p.length > SAFE_CHUNK_CHARS) flush()
                if (current.isNotEmpty()) current.append("\n\n")
                current.append(p)
            }
        }
        flush()
        return chunks.ifEmpty { listOf(normalized) }
    }
}
