package com.amintranslate.nativepro

data class LanguageOption(
    val code: String,
    val labelFa: String,
    val labelEn: String
)

val supportedLanguages = listOf(
    LanguageOption("fa", "فارسی", "Persian"),
    LanguageOption("en", "انگلیسی", "English"),
    LanguageOption("ar", "عربی", "Arabic"),
    LanguageOption("tr", "ترکی", "Turkish"),
    LanguageOption("fr", "فرانسوی", "French"),
    LanguageOption("de", "آلمانی", "German"),
    LanguageOption("es", "اسپانیایی", "Spanish"),
    LanguageOption("it", "ایتالیایی", "Italian"),
    LanguageOption("ru", "روسی", "Russian"),
    LanguageOption("uk", "اوکراینی", "Ukrainian"),
    LanguageOption("pt", "پرتغالی", "Portuguese"),
    LanguageOption("hi", "هندی", "Hindi"),
    LanguageOption("ur", "اردو", "Urdu"),
    LanguageOption("ja", "ژاپنی", "Japanese"),
    LanguageOption("ko", "کره‌ای", "Korean"),
    LanguageOption("zh", "چینی", "Chinese"),
    LanguageOption("af", "آفریکانس", "Afrikaans"),
    LanguageOption("be", "بلاروسی", "Belarusian"),
    LanguageOption("bg", "بلغاری", "Bulgarian"),
    LanguageOption("bn", "بنگالی", "Bengali"),
    LanguageOption("ca", "کاتالان", "Catalan"),
    LanguageOption("cs", "چکی", "Czech"),
    LanguageOption("cy", "ولزی", "Welsh"),
    LanguageOption("da", "دانمارکی", "Danish"),
    LanguageOption("el", "یونانی", "Greek"),
    LanguageOption("eo", "اسپرانتو", "Esperanto"),
    LanguageOption("et", "استونیایی", "Estonian"),
    LanguageOption("fi", "فنلاندی", "Finnish"),
    LanguageOption("ga", "ایرلندی", "Irish"),
    LanguageOption("gl", "گالیسیایی", "Galician"),
    LanguageOption("gu", "گجراتی", "Gujarati"),
    LanguageOption("he", "عبری", "Hebrew"),
    LanguageOption("hr", "کرواتی", "Croatian"),
    LanguageOption("ht", "هائیتی", "Haitian"),
    LanguageOption("hu", "مجاری", "Hungarian"),
    LanguageOption("id", "اندونزیایی", "Indonesian"),
    LanguageOption("is", "ایسلندی", "Icelandic"),
    LanguageOption("ka", "گرجی", "Georgian"),
    LanguageOption("kn", "کانادایی", "Kannada"),
    LanguageOption("lt", "لیتوانیایی", "Lithuanian"),
    LanguageOption("lv", "لتونیایی", "Latvian"),
    LanguageOption("mk", "مقدونی", "Macedonian"),
    LanguageOption("mr", "مراتی", "Marathi"),
    LanguageOption("ms", "مالایی", "Malay"),
    LanguageOption("mt", "مالتی", "Maltese"),
    LanguageOption("nl", "هلندی", "Dutch"),
    LanguageOption("no", "نروژی", "Norwegian"),
    LanguageOption("pl", "لهستانی", "Polish"),
    LanguageOption("ro", "رومانیایی", "Romanian"),
    LanguageOption("sk", "اسلواکی", "Slovak"),
    LanguageOption("sl", "اسلوونیایی", "Slovenian"),
    LanguageOption("sq", "آلبانیایی", "Albanian"),
    LanguageOption("sv", "سوئدی", "Swedish"),
    LanguageOption("sw", "سواحیلی", "Swahili"),
    LanguageOption("ta", "تامیلی", "Tamil"),
    LanguageOption("te", "تلوگو", "Telugu"),
    LanguageOption("th", "تایلندی", "Thai"),
    LanguageOption("tl", "تاگالوگ", "Tagalog"),
    LanguageOption("vi", "ویتنامی", "Vietnamese")
)


enum class TranslationDomain(val labelFa: String, val subtitleFa: String) {
    AUTO_EXPERT("هوشمند تخصصی", "تشخیص خودکار حوزه و واژگان حرفه‌ای"),
    MEDICAL_LAB("پزشکی و آزمایشگاه", "میکروب، ایمنی، پاتولوژی، تشخیص و بالین"),
    SCIENTIFIC_ACADEMIC("علمی و دانشگاهی", "مقاله، پژوهش، آمار و نگارش آکادمیک"),
    ENGINEERING_IT("مهندسی و IT", "نرم‌افزار، هوش مصنوعی، داده و امنیت"),
    LEGAL_BUSINESS("حقوقی و مدیریتی", "قرارداد، مدیریت، مالی و اداری"),
    GENERAL("عمومی", "ترجمه روان روزمره")
}

data class HistoryEntry(
    val id: Long,
    val kind: String,
    val sourceCode: String,
    val targetCode: String,
    val input: String,
    val output: String,
    val createdAt: Long
)

data class SubtitleCue(
    val startMs: Long,
    val endMs: Long,
    val sourceText: String,
    val translatedText: String
)

data class SpeechSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

data class SpeechTranscription(
    val text: String,
    val segments: List<SpeechSegment>,
    val processingTimeMs: Long
)

data class AppUiState(
    val sourceLanguage: LanguageOption = supportedLanguages.first { it.code == "en" },
    val targetLanguage: LanguageOption = supportedLanguages.first { it.code == "fa" },
    val inputText: String = "",
    val outputText: String = "",
    val busy: Boolean = false,
    val status: String = "آماده برای ترجمه",
    val error: String? = null,
    val history: List<HistoryEntry> = emptyList(),
    val ocrLanguage: String = "fas+eng",
    val speechModel: String = "base",
    val detectedSpeechLanguage: String = "",
    val imageTranscript: String = "",
    val audioTranscript: String = "",
    val audioSubtitles: List<SubtitleCue> = emptyList(),
    val videoTranscript: String = "",
    val videoTranslation: String = "",
    val videoSubtitles: List<SubtitleCue> = emptyList(),
    val lastProcessingMs: Long = 0L,
    val onlineVideoUrl: String = "",
    val onlineTranscript: String = "",
    val onlineSubtitles: List<SubtitleCue> = emptyList(),
    val darkMode: Boolean = true,
    val translationDomain: TranslationDomain = TranslationDomain.AUTO_EXPERT,
    val onlineExpertEnabled: Boolean = false,
    val aiConfigured: Boolean = false,
    val aiKeyDraft: String = "",
    val aiModel: String = "gpt-6-astra",
    val lastTranslationEngine: String = "Expert Local"
)
