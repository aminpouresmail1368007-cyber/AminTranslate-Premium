package com.amintranslate.nativepro

import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object DownloadUtils {
    private const val CONNECT_TIMEOUT_MS = 15_000
    private const val READ_TIMEOUT_MS = 45_000
    private const val MAX_TOTAL_DOWNLOAD_MS = 15 * 60_000L
    private const val FREE_SPACE_MARGIN_BYTES = 32L * 1024 * 1024

    suspend fun download(url: String, destination: File, onProgress: (Int) -> Unit = {}) = withContext(Dispatchers.IO) {
        require(url.startsWith("https://")) { "دانلود فقط از اتصال امن HTTPS مجاز است." }
        coroutineContext.ensureActive()
        destination.parentFile?.mkdirs()
        val part = File(destination.parentFile, destination.name + ".part")
        if (part.exists()) part.delete()

        var connection: HttpURLConnection? = null
        val startedAt = SystemClock.elapsedRealtime()
        try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "AminTranslate/4.2.2 Android")
                setRequestProperty("Accept", "*/*")
                connect()
            }

            val code = connection.responseCode
            if (code !in 200..299) error("خطا در دانلود: HTTP $code")

            val total = connection.contentLengthLong
            if (total > 0) {
                val available = destination.parentFile?.usableSpace ?: Long.MAX_VALUE
                check(available > total + FREE_SPACE_MARGIN_BYTES) {
                    "فضای خالی گوشی برای دانلود این مدل کافی نیست."
                }
            }

            connection.inputStream.use { input ->
                part.outputStream().buffered(128 * 1024).use { output ->
                    val buffer = ByteArray(128 * 1024)
                    var downloaded = 0L
                    var lastProgress = -1
                    while (true) {
                        coroutineContext.ensureActive()
                        if (SystemClock.elapsedRealtime() - startedAt > MAX_TOTAL_DOWNLOAD_MS) {
                            error("دانلود بیش از ۱۵ دقیقه طول کشید و برای جلوگیری از گیرکردن متوقف شد.")
                        }
                        val read = input.read(buffer)
                        if (read < 0) break
                        if (read == 0) continue
                        output.write(buffer, 0, read)
                        downloaded += read
                        if (total > 0) {
                            val progress = ((downloaded * 100L) / total).toInt().coerceIn(0, 100)
                            if (progress != lastProgress) {
                                lastProgress = progress
                                onProgress(progress)
                            }
                        }
                    }
                    output.flush()
                }
            }

            check(part.exists() && part.length() > 0) { "فایل دانلودشده خالی است." }
            if (destination.exists() && !destination.delete()) {
                error("جایگزینی فایل قبلی انجام نشد.")
            }
            check(part.renameTo(destination)) { "ذخیره فایل دانلودشده انجام نشد." }
            onProgress(100)
        } catch (t: Throwable) {
            part.delete()
            throw t
        } finally {
            runCatching { connection?.disconnect() }
        }
    }

    fun unzip(zipFile: File, destination: File) {
        destination.mkdirs()
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destination, entry.name)
                val canonicalDest = destination.canonicalFile
                val canonicalOut = outFile.canonicalFile
                require(canonicalOut.path.startsWith(canonicalDest.path + File.separator) || canonicalOut == canonicalDest) {
                    "Invalid zip entry"
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    outFile.outputStream().use { output -> zis.copyTo(output) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
