package com.amintranslate.nativepro

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.mlkit.nl.translate.TranslateLanguage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val translator = TranslationEngine()
    private val aiTranslator = AiTranslationClient()
    private val secretStore = SecretStore(application)
    private val historyStore = HistoryStore(application)
    private val ocrEngine = OcrEngine(application)
    private val speechTranscriber = WhisperTranscriber(application)
    private val languageDetector = LanguageDetector()
    private var activeJob: Job? = null

    private val _state = MutableStateFlow(
        AppUiState(
            history = historyStore.load(),
            aiConfigured = secretStore.hasApiKey(),
            aiModel = secretStore.loadModel(),
            onlineExpertEnabled = secretStore.hasApiKey()
        )
    )
    val state: StateFlow<AppUiState> = _state.asStateFlow()

    fun setInput(value: String) { if (!_state.value.busy) _state.update { it.copy(inputText = value, error = null) } }
    fun setSource(language: LanguageOption) { if (!_state.value.busy) _state.update { it.copy(sourceLanguage = language, outputText = "", error = null) } }
    fun setTarget(language: LanguageOption) { if (!_state.value.busy) _state.update { it.copy(targetLanguage = language, outputText = "", error = null) } }
    fun setSpeechModel(value: String) { if (!_state.value.busy) _state.update { it.copy(speechModel = value, error = null) } }
    fun setOnlineVideoUrl(value: String) { if (!_state.value.busy) _state.update { it.copy(onlineVideoUrl = value, error = null) } }
    fun setTranslationDomain(value: TranslationDomain) { if (!_state.value.busy) _state.update { it.copy(translationDomain = value, error = null) } }
    fun setOnlineExpertEnabled(value: Boolean) {
        if (_state.value.busy) return
        if (value && !secretStore.hasApiKey()) {
            _state.update { it.copy(onlineExpertEnabled = false, error = "برای فعال‌کردن AI آنلاین، ابتدا کلید API را در تنظیمات ذخیره کن.") }
        } else {
            _state.update { it.copy(onlineExpertEnabled = value, error = null) }
        }
    }
    fun setAiKeyDraft(value: String) = _state.update { it.copy(aiKeyDraft = value, error = null) }
    fun setAiModel(value: String) = _state.update { it.copy(aiModel = value, error = null) }

    fun reportError(message: String) = _state.update { it.copy(error = message, status = "عملیات انجام نشد", busy = false) }
    fun reportStatus(message: String) = setStatus(message)

    fun cancelCurrentOperation() {
        activeJob?.cancel()
        activeJob = null
        _state.update { it.copy(busy = false, status = "عملیات توسط کاربر متوقف شد", error = null) }
    }

    fun saveAiSettings() {
        val snapshot = _state.value
        if (snapshot.aiKeyDraft.isNotBlank()) secretStore.saveApiKey(snapshot.aiKeyDraft)
        secretStore.saveModel(snapshot.aiModel)
        _state.update {
            it.copy(
                aiConfigured = secretStore.hasApiKey(),
                onlineExpertEnabled = secretStore.hasApiKey(),
                aiKeyDraft = "",
                status = if (secretStore.hasApiKey()) "AI آنلاین تخصصی فعال شد" else "مدل AI ذخیره شد؛ کلید API هنوز تنظیم نشده",
                error = null
            )
        }
    }

    fun clearAiKey() {
        secretStore.saveApiKey("")
        _state.update { it.copy(aiConfigured = false, onlineExpertEnabled = false, aiKeyDraft = "", status = "کلید AI حذف شد؛ موتور تخصصی محلی فعال است", error = null) }
    }

    fun swapLanguages() {
        if (_state.value.busy) return
        _state.update {
            it.copy(
                sourceLanguage = it.targetLanguage,
                targetLanguage = it.sourceLanguage,
                inputText = if (it.outputText.isNotBlank()) it.outputText else it.inputText,
                outputText = "",
                error = null
            )
        }
    }

    fun translateCurrent(kind: String = "text") {
        val snapshot = _state.value
        if (snapshot.inputText.isBlank()) {
            _state.update { it.copy(error = "اول متن را وارد کن.") }
            return
        }
        runTranslation(snapshot.inputText, kind)
    }

    fun useVoiceResult(text: String) {
        if (text.isBlank()) {
            _state.update { it.copy(error = "صدایی تشخیص داده نشد.") }
            return
        }
        _state.update { it.copy(inputText = text, status = "گفتار دریافت شد؛ در حال ترجمه…", error = null) }
        runTranslation(text, "voice")
    }

    fun processImage(uri: Uri) {
        val app = getApplication<Application>()
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            setBusy("در حال آماده‌سازی OCR…")
            try {
                val recognized = withContext(Dispatchers.IO) {
                    ocrEngine.ensureModels(_state.value.ocrLanguage) { status -> setStatus(status) }
                    val bitmap = decodeBitmapSafely(app, uri)
                    try {
                        ocrEngine.recognize(bitmap, _state.value.ocrLanguage)
                    } finally {
                        bitmap.recycle()
                    }
                }
                if (recognized.isBlank()) error("متنی در تصویر پیدا نشد.")
                _state.update { it.copy(inputText = recognized, status = "متن تصویر استخراج شد؛ در حال ترجمه…") }
                translateAndStore(recognized, "image")
            } catch (t: Throwable) {
                fail(t)
            } finally {
                activeJob = null
            }
        }
    }

    fun setOcrLanguage(value: String) { if (!_state.value.busy) _state.update { it.copy(ocrLanguage = value, error = null) } }

    fun processAudio(uri: Uri) {
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            setBusy("در حال آماده‌سازی فایل صوتی…")
            try {
                val result = speechTranscriber.transcribe(uri, _state.value.speechModel) { setStatus(it) }
                handleSpeechResult(result, "audio", audio = true)
            } catch (t: Throwable) {
                fail(t)
            } finally {
                activeJob = null
            }
        }
    }

    fun processVideo(uri: Uri) {
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            setBusy("در حال آماده‌سازی صدای ویدیو…")
            try {
                val result = speechTranscriber.transcribe(uri, _state.value.speechModel) { setStatus(it) }
                handleSpeechResult(result, "video", video = true)
            } catch (t: Throwable) {
                fail(t)
            } finally {
                activeJob = null
            }
        }
    }

    fun processOnlineVideo() {
        val url = _state.value.onlineVideoUrl.trim()
        if (url.isBlank()) {
            _state.update { it.copy(error = "اول لینک ویدیو را وارد کن.") }
            return
        }
        if (!url.startsWith("https://")) {
            _state.update { it.copy(error = "برای امنیت، لینک باید با https:// شروع شود.") }
            return
        }
        val lower = url.lowercase()
        if (listOf("youtube.com/watch", "youtu.be/", "instagram.com/", "tiktok.com/").any { it in lower }) {
            _state.update { it.copy(error = "این لینک، صفحهٔ سرویس است نه فایل مستقیم رسانه. برای ترجمه، فایل ویدیو را از گوشی انتخاب کن یا لینک مستقیم فایل MP4/MP3/M4A/WebM بده.") }
            return
        }
        if (lower.substringBefore('?').endsWith(".m3u8") || lower.substringBefore('?').endsWith(".mpd")) {
            _state.update { it.copy(error = "HLS/DASH برای پخش آنلاین مناسب است، اما ترجمه در این نسخه به لینک مستقیم فایل رسانه نیاز دارد. فایل یا لینک مستقیم MP4/MP3/M4A/WebM را بده.") }
            return
        }
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            setBusy("در حال خواندن صدای ویدیوی آنلاین…")
            try {
                val result = speechTranscriber.transcribeUrl(url, _state.value.speechModel) { setStatus(it) }
                if (result.text.isBlank()) error("گفتاری در ویدیوی آنلاین تشخیص داده نشد.")
                val detected = detectSource(result.text)
                val target = _state.value.targetLanguage.code
                setStatus("زبان $detected تشخیص داده شد؛ در حال ساخت زیرنویس ترجمه‌شده…")

                val sourceSegments = result.segments.ifEmpty {
                    listOf(SpeechSegment(0, Long.MAX_VALUE, result.text))
                }
                val translatedSegments = translateSafely(sourceSegments.map { it.text }, detected, target)
                val cues = sourceSegments.zip(translatedSegments).map { (seg, translated) ->
                    SubtitleCue(seg.startMs, seg.endMs, seg.text, translated)
                }
                val translatedFull = translatedSegments.joinToString(" ").replace(Regex("\\s+"), " ").trim()

                _state.update {
                    it.copy(
                        inputText = result.text,
                        outputText = translatedFull,
                        onlineTranscript = result.text,
                        onlineSubtitles = cues,
                        lastProcessingMs = result.processingTimeMs,
                        detectedSpeechLanguage = detected,
                        busy = false,
                        status = "زیرنویس و ترجمه ویدیوی آنلاین آماده شد",
                        error = null
                    )
                }
                saveHistory("online_video", detected, target, result.text, translatedFull)
            } catch (t: Throwable) {
                fail(t)
            } finally {
                activeJob = null
            }
        }
    }

    private suspend fun handleSpeechResult(
        result: SpeechTranscription,
        kind: String,
        audio: Boolean = false,
        video: Boolean = false
    ) {
        if (result.text.isBlank()) error("گفتاری از فایل استخراج نشد.")
        val detected = detectSource(result.text)
        val target = _state.value.targetLanguage.code
        setStatus("زبان $detected تشخیص داده شد؛ در حال ترجمه بخش‌به‌بخش…")

        val sourceSegments = result.segments.ifEmpty { listOf(SpeechSegment(0, Long.MAX_VALUE, result.text)) }
        val translatedSegments = translateSafely(sourceSegments.map { it.text }, detected, target)
        val cues = sourceSegments.zip(translatedSegments).map { (seg, translated) ->
            SubtitleCue(seg.startMs, seg.endMs, seg.text, translated)
        }
        val translated = translatedSegments.joinToString(" ").replace(Regex("\\s+"), " ").trim()

        _state.update {
            it.copy(
                inputText = result.text,
                outputText = translated,
                audioTranscript = if (audio) result.text else it.audioTranscript,
                audioSubtitles = if (audio) cues else it.audioSubtitles,
                videoTranscript = if (video) result.text else it.videoTranscript,
                videoTranslation = if (video) translated else it.videoTranslation,
                videoSubtitles = if (video) cues else it.videoSubtitles,
                lastProcessingMs = result.processingTimeMs,
                detectedSpeechLanguage = detected,
                busy = false,
                status = "تبدیل گفتار، زمان‌بندی و ترجمه کامل شد",
                error = null
            )
        }
        saveHistory(kind, detected, target, result.text, translated)
    }

    private suspend fun detectSource(text: String): String {
        val detected = languageDetector.detect(text)
        return if (detected == "und") _state.value.sourceLanguage.code else detected.substringBefore('-')
    }

    private suspend fun translateSafely(texts: List<String>, source: String, target: String): List<String> {
        if (source == target) return texts
        val result = smartTranslateMany(texts, source, target)
        return result.first
    }

    fun exportAudioTxt() = exportTxt("audio", _state.value.audioTranscript, _state.value.outputText)
    fun exportAudioSrt() = exportSrt("audio", _state.value.audioSubtitles)
    fun exportVideoTxt() = exportTxt("video", _state.value.videoTranscript, _state.value.videoTranslation)
    fun exportVideoSrt() = exportSrt("video", _state.value.videoSubtitles)
    fun exportOnlineTxt() = exportTxt("online_video", _state.value.onlineTranscript, _state.value.outputText)
    fun exportOnlineSrt() = exportSrt("online_video", _state.value.onlineSubtitles)

    private fun exportTxt(prefix: String, source: String, translated: String) {
        if (source.isBlank()) {
            _state.update { it.copy(error = "متنی برای ذخیره وجود ندارد.") }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { TranscriptExporter.saveTxt(getApplication<Application>(), prefix, source, translated) }
                .onSuccess { path -> _state.update { it.copy(status = "فایل ذخیره شد: $path", error = null) } }
                .onFailure { fail(it) }
        }
    }

    private fun exportSrt(prefix: String, cues: List<SubtitleCue>) {
        if (cues.isEmpty()) {
            _state.update { it.copy(error = "زیرنویس زمان‌دار برای ذخیره وجود ندارد.") }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { TranscriptExporter.saveSrt(getApplication<Application>(), prefix, cues) }
                .onSuccess { path -> _state.update { it.copy(status = "زیرنویس ذخیره شد: $path", error = null) } }
                .onFailure { fail(it) }
        }
    }

    fun clearHistory() {
        historyStore.clear()
        _state.update { it.copy(history = emptyList(), status = "تاریخچه پاک شد") }
    }

    fun setDarkMode(enabled: Boolean) = _state.update { it.copy(darkMode = enabled) }

    private fun runTranslation(text: String, kind: String) {
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            setBusy("در حال آماده‌سازی مدل ترجمه…")
            try {
                withTimeout(150_000L) {
                    translateAndStore(text, kind)
                }
            } catch (_: TimeoutCancellationException) {
                reportError("ترجمه بیش از حد طول کشید و برای جلوگیری از گیرکردن متوقف شد. اینترنت را بررسی کن و دوباره تلاش کن.")
            } catch (t: Throwable) {
                fail(t)
            } finally {
                activeJob = null
            }
        }
    }

    private suspend fun translateAndStore(text: String, kind: String) {
        val source = _state.value.sourceLanguage.code
        val target = _state.value.targetLanguage.code
        setStatus("در حال ترجمه ${_state.value.sourceLanguage.labelFa} → ${_state.value.targetLanguage.labelFa}…")
        val (translations, engine) = smartTranslateMany(listOf(text), source, target)
        val translated = translations.first()
        _state.update {
            it.copy(
                outputText = translated,
                busy = false,
                status = "ترجمه تخصصی با موفقیت انجام شد — $engine",
                lastTranslationEngine = engine,
                error = null
            )
        }
        saveHistory(kind, source, target, text, translated)
    }

    private suspend fun smartTranslateMany(
        texts: List<String>,
        sourceCode: String,
        targetCode: String
    ): Pair<List<String>, String> {
        val snapshot = _state.value
        val source = supportedLanguages.firstOrNull { it.code == sourceCode.substringBefore('-') }
            ?: LanguageOption(sourceCode.substringBefore('-'), sourceCode, sourceCode)
        val target = supportedLanguages.firstOrNull { it.code == targetCode.substringBefore('-') }
            ?: LanguageOption(targetCode.substringBefore('-'), targetCode, targetCode)

        if (snapshot.onlineExpertEnabled && secretStore.hasApiKey()) {
            try {
                setStatus("AI آنلاین در حال ترجمه تخصصی ${snapshot.translationDomain.labelFa}…")
                val translated = aiTranslator.translateMany(
                    texts = texts,
                    source = source,
                    target = target,
                    domain = snapshot.translationDomain,
                    apiKey = secretStore.loadApiKey(),
                    model = snapshot.aiModel
                )
                _state.update { it.copy(lastTranslationEngine = "AI Online • ${snapshot.aiModel}") }
                return translated to "AI Online • ${snapshot.aiModel}"
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                setStatus("AI آنلاین در دسترس نبود؛ ترجمه تخصصی محلی به‌صورت خودکار ادامه دارد")
            }
        }

        if (TranslateLanguage.fromLanguageTag(sourceCode.substringBefore('-')) == null ||
            TranslateLanguage.fromLanguageTag(targetCode.substringBefore('-')) == null
        ) {
            val original = texts.map { "$it\n\n[برای این جفت‌زبان، AI آنلاین را با کلید API فعال کن.]" }
            _state.update { it.copy(lastTranslationEngine = "Unsupported Local Pair") }
            return original to "Unsupported Local Pair"
        }

        setStatus("موتور تخصصی محلی + واژه‌نامه حرفه‌ای در حال ترجمه…")
        val translated = translator.translateMany(
            texts = texts,
            source = sourceCode,
            target = targetCode,
            domain = snapshot.translationDomain,
            onStatus = ::setStatus
        )
        _state.update { it.copy(lastTranslationEngine = "Expert Local • ${snapshot.translationDomain.labelFa}") }
        return translated to "Expert Local • ${snapshot.translationDomain.labelFa}"
    }

    private fun saveHistory(kind: String, source: String, target: String, input: String, output: String) {
        val entry = HistoryEntry(
            id = System.currentTimeMillis(),
            kind = kind,
            sourceCode = source,
            targetCode = target,
            input = input,
            output = output,
            createdAt = System.currentTimeMillis()
        )
        historyStore.save(entry)
        _state.update { it.copy(history = historyStore.load()) }
    }

    private fun decodeBitmapSafely(app: Application, uri: Uri): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        app.contentResolver.openInputStream(uri).use { stream ->
            requireNotNull(stream) { "تصویر قابل خواندن نیست." }
            BitmapFactory.decodeStream(stream, null, bounds)
        }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "ابعاد تصویر قابل تشخیص نیست." }

        var sample = 1
        val maxDimension = 2600
        while (bounds.outWidth / sample > maxDimension || bounds.outHeight / sample > maxDimension) {
            sample *= 2
        }
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val decoded = app.contentResolver.openInputStream(uri).use { stream ->
            requireNotNull(stream) { "تصویر قابل خواندن نیست." }
            BitmapFactory.decodeStream(stream, null, options)
        } ?: error("تصویر قابل پردازش نیست.")

        val orientation = runCatching {
            app.contentResolver.openInputStream(uri).use { stream ->
                if (stream == null) ExifInterface.ORIENTATION_NORMAL
                else ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)

        val rotation = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90, ExifInterface.ORIENTATION_TRANSPOSE -> 90f
            ExifInterface.ORIENTATION_ROTATE_180, ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180f
            ExifInterface.ORIENTATION_ROTATE_270, ExifInterface.ORIENTATION_TRANSVERSE -> 270f
            else -> 0f
        }
        if (rotation == 0f) return decoded

        val matrix = Matrix().apply { postRotate(rotation) }
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded) decoded.recycle()
        return rotated
    }

    private fun setBusy(status: String) = _state.update { it.copy(busy = true, status = status, error = null) }
    private fun setStatus(status: String) = _state.update { it.copy(status = status) }

    private fun fail(t: Throwable) {
        if (t is CancellationException) {
            _state.update { it.copy(busy = false, status = "عملیات متوقف شد", error = null) }
            return
        }
        val message = t.message?.takeIf { it.isNotBlank() } ?: "خطای ناشناخته"
        _state.update {
            it.copy(busy = false, status = "عملیات متوقف شد", error = message)
        }
    }
}
