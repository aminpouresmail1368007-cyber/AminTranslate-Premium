package com.amintranslate.nativepro

import com.google.mlkit.nl.languageid.LanguageIdentification
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

class LanguageDetector {
    suspend fun detect(text: String): String {
        if (text.isBlank()) return "und"
        val identifier = LanguageIdentification.getClient()
        return try {
            try {
                withTimeout(10_000L) {
                    identifier.identifyLanguage(text.take(6000)).await()
                }
            } catch (_: TimeoutCancellationException) {
                "und"
            }
        } finally {
            identifier.close()
        }
    }
}
