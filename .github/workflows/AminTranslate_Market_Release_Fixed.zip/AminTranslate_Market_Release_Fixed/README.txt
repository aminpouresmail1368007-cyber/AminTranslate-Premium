فایل داخل این پوشه برای GitHub Actions است.
فقط فایل build-market-release.yml را داخل مسیر .github/workflows آپلود کنید.
Secret مورد نیاز: AMIN_MARKET_SIGNING_B64
